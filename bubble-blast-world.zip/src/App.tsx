/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  PlayerStats,
  ScreenState,
} from './game/types';
import {
  loadPlayerStats,
  savePlayerStats,
  checkNewAchievements,
  INITIAL_STATS,
} from './game/storage';
import { sound } from './game/sound';
import { adMobService, AdType } from './game/admob';
import { MainMenu } from './components/MainMenu';
import { LevelSelectScreen } from './components/LevelSelectScreen';
import { GameplayScreen } from './components/GameplayScreen';
import { PauseModal } from './components/PauseModal';
import { LevelCompleteModal } from './components/LevelCompleteModal';
import { GameOverModal } from './components/GameOverModal';
import { ShopModal } from './components/ShopModal';
import { DailyRewardsModal } from './components/DailyRewardsModal';
import { AchievementsModal } from './components/AchievementsModal';
import { ProfileModal } from './components/ProfileModal';
import { SettingsModal } from './components/SettingsModal';
import { LeaderboardModal } from './components/LeaderboardModal';
import { AndroidExportModal } from './components/AndroidExportModal';
import { AdMobModal } from './components/AdMobModal';
import { Smartphone, Monitor } from 'lucide-react';

export default function App() {
  const [stats, setStats] = useState<PlayerStats>(loadPlayerStats);
  const [screen, setScreen] = useState<ScreenState>('MAIN_MENU');
  const [currentLevel, setCurrentLevel] = useState<number>(stats.unlockedLevel || 1);

  // Modals
  const [isPauseOpen, setIsPauseOpen] = useState(false);
  const [isShopOpen, setIsShopOpen] = useState(false);
  const [isDailyOpen, setIsDailyOpen] = useState(false);
  const [isAchievementsOpen, setIsAchievementsOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isLeaderboardOpen, setIsLeaderboardOpen] = useState(false);
  const [isAndroidExportOpen, setIsAndroidExportOpen] = useState(false);

  // AdMob Modal State
  const [adModalOpen, setAdModalOpen] = useState(false);
  const [adType, setAdType] = useState<AdType>('REWARDED_MOVES');
  const [onAdRewardCallback, setOnAdRewardCallback] = useState<(() => void) | null>(null);

  // Gameplay Outcome State
  const [isLevelCompleteOpen, setIsLevelCompleteOpen] = useState(false);
  const [isGameOverOpen, setIsGameOverOpen] = useState(false);
  const [lastScore, setLastScore] = useState(0);
  const [lastStars, setLastStars] = useState(0);
  const [lastCoinsEarned, setLastCoinsEarned] = useState(0);
  const [lastRemainingMoves, setLastRemainingMoves] = useState(0);
  const [lastGameOverGoal, setLastGameOverGoal] = useState('');
  const [extraMovesGranted, setExtraMovesGranted] = useState(0);

  // Device frame toggle on desktop
  const [useDeviceFrame, setUseDeviceFrame] = useState(true);

  // Sound settings synchronization
  useEffect(() => {
    sound.updateSettings(
      stats.soundEnabled,
      stats.musicEnabled,
      stats.soundVolume ?? 0.8,
      stats.musicVolume ?? 0.5
    );
  }, []);

  // Update and persist stats
  const handleUpdateStats = (newStats: PlayerStats) => {
    const { updatedStats } = checkNewAchievements(newStats);
    setStats(updatedStats);
    savePlayerStats(updatedStats);
  };

  // Start Level
  const startLevel = (lvl: number) => {
    setCurrentLevel(lvl);
    setIsLevelCompleteOpen(false);
    setIsGameOverOpen(false);
    setIsPauseOpen(false);
    setExtraMovesGranted(0);
    setScreen('GAMEPLAY');
  };

  // Level Complete Handler
  const handleLevelComplete = (finalScore: number, stars: number, remainingMoves: number) => {
    const baseCoins = 50 + stars * 25 + remainingMoves * 5;

    // Check if new highest level unlocked
    const nextLevel = Math.min(500, currentLevel + 1);
    const newUnlocked = Math.max(stats.unlockedLevel, nextLevel);

    const updatedStars = {
      ...stats.levelStars,
      [currentLevel]: Math.max(stats.levelStars[currentLevel] || 0, stars),
    };

    const updatedHighScores = {
      ...stats.levelHighScores,
      [currentLevel]: Math.max(stats.levelHighScores[currentLevel] || 0, finalScore),
    };

    const updatedStats: PlayerStats = {
      ...stats,
      coins: stats.coins + baseCoins,
      unlockedLevel: newUnlocked,
      levelStars: updatedStars,
      levelHighScores: updatedHighScores,
      totalBubblesPopped: stats.totalBubblesPopped + 25,
    };

    handleUpdateStats(updatedStats);

    setLastScore(finalScore);
    setLastStars(stars);
    setLastCoinsEarned(baseCoins);
    setLastRemainingMoves(remainingMoves);
    setIsLevelCompleteOpen(true);
  };

  // Game Over Handler
  const handleGameOver = (finalScore: number, goalDesc: string) => {
    setLastScore(finalScore);
    setLastGameOverGoal(goalDesc);
    setIsGameOverOpen(true);
  };

  // Watch AdMob Video
  const handleTriggerAd = (type: AdType, onReward: () => void) => {
    setAdType(type);
    setOnAdRewardCallback(() => onReward);
    setAdModalOpen(true);
  };

  // Reset Progress
  const handleResetProgress = () => {
    setStats(INITIAL_STATS);
    savePlayerStats(INITIAL_STATS);
    setCurrentLevel(1);
    setScreen('MAIN_MENU');
  };

  return (
    <div className="relative min-h-screen w-full bg-slate-950 flex flex-col items-center justify-center font-sans antialiased">
      {/* Desktop Device Frame Switcher */}
      <div className="hidden sm:flex items-center gap-3 py-2 px-4 bg-slate-900/90 rounded-full border border-slate-800 text-xs text-slate-400 mb-3 shadow-md z-30">
        <span className="font-semibold text-slate-300">Bubble Blast World</span>
        <span>·</span>
        <button
          onClick={() => setUseDeviceFrame(!useDeviceFrame)}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold transition-all"
        >
          {useDeviceFrame ? <Monitor className="w-3.5 h-3.5" /> : <Smartphone className="w-3.5 h-3.5" />}
          <span>{useDeviceFrame ? 'Full Screen Mode' : 'Mobile Phone Frame'}</span>
        </button>
      </div>

      {/* Main Game Shell */}
      <div
        className={`relative overflow-hidden transition-all duration-300 ${
          useDeviceFrame
            ? 'w-full max-w-[420px] h-[100dvh] sm:h-[840px] sm:max-h-[92vh] sm:rounded-[42px] sm:border-[8px] sm:border-slate-800 sm:ring-1 sm:ring-white/10 sm:shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)]'
            : 'w-full h-[100dvh]'
        } flex flex-col bg-slate-950`}
      >
        {/* Fantasy Landscape Background Texture */}
        <div
          className="absolute inset-0 bg-cover bg-center pointer-events-none opacity-20 filter brightness-90"
          style={{
            backgroundImage: `url('/src/assets/images/bubble_world_bg_1793378045715.jpg')`,
          }}
        />

        {/* Ambient Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-indigo-950/40 via-slate-950/80 to-slate-950 pointer-events-none" />

        {/* SCREEN 1: MAIN MENU */}
        {screen === 'MAIN_MENU' && (
          <MainMenu
            stats={stats}
            onPlay={() => startLevel(stats.unlockedLevel)}
            onOpenLevelSelect={() => setScreen('LEVEL_SELECT')}
            onOpenShop={() => setIsShopOpen(true)}
            onOpenDailyRewards={() => setIsDailyOpen(true)}
            onOpenAchievements={() => setIsAchievementsOpen(true)}
            onOpenLeaderboard={() => setIsLeaderboardOpen(true)}
            onOpenProfile={() => setIsProfileOpen(true)}
            onOpenSettings={() => setIsSettingsOpen(true)}
            onOpenAndroidExport={() => setIsAndroidExportOpen(true)}
          />
        )}

        {/* SCREEN 2: LEVEL SELECTION */}
        {screen === 'LEVEL_SELECT' && (
          <LevelSelectScreen
            stats={stats}
            onSelectLevel={(lvl) => startLevel(lvl)}
            onBackToMenu={() => setScreen('MAIN_MENU')}
            onOpenShop={() => setIsShopOpen(true)}
          />
        )}

        {/* SCREEN 3: GAMEPLAY */}
        {screen === 'GAMEPLAY' && (
          <GameplayScreen
            levelNumber={currentLevel}
            stats={stats}
            extraMovesGranted={extraMovesGranted}
            onLevelComplete={handleLevelComplete}
            onGameOver={handleGameOver}
            onPause={() => setIsPauseOpen(true)}
            onOpenShop={() => setIsShopOpen(true)}
            onUpdateStats={handleUpdateStats}
          />
        )}

        {/* IN-GAME MODALS */}

        {/* 1. Pause Menu */}
        <PauseModal
          levelNumber={currentLevel}
          isOpen={isPauseOpen}
          soundEnabled={stats.soundEnabled}
          musicEnabled={stats.musicEnabled}
          soundVolume={stats.soundVolume ?? 0.8}
          musicVolume={stats.musicVolume ?? 0.5}
          hapticEnabled={stats.hapticEnabled}
          onResume={() => setIsPauseOpen(false)}
          onRestart={() => startLevel(currentLevel)}
          onLevelSelect={() => {
            setIsPauseOpen(false);
            setScreen('LEVEL_SELECT');
          }}
          onToggleSound={() => {
            const next = !stats.soundEnabled;
            sound.updateSettings(next, stats.musicEnabled, stats.soundVolume ?? 0.8, stats.musicVolume ?? 0.5);
            handleUpdateStats({ ...stats, soundEnabled: next });
          }}
          onToggleMusic={() => {
            const next = !stats.musicEnabled;
            sound.updateSettings(stats.soundEnabled, next, stats.soundVolume ?? 0.8, stats.musicVolume ?? 0.5);
            handleUpdateStats({ ...stats, musicEnabled: next });
          }}
          onChangeSoundVolume={(vol) => {
            sound.setVolume(vol, stats.musicVolume ?? 0.5);
            handleUpdateStats({ ...stats, soundVolume: vol });
          }}
          onChangeMusicVolume={(vol) => {
            sound.setVolume(stats.soundVolume ?? 0.8, vol);
            handleUpdateStats({ ...stats, musicVolume: vol });
          }}
          onToggleHaptic={() => {
            handleUpdateStats({ ...stats, hapticEnabled: !stats.hapticEnabled });
          }}
        />

        {/* 2. Level Complete Modal */}
        <LevelCompleteModal
          levelNumber={currentLevel}
          score={lastScore}
          starsEarned={lastStars}
          coinsEarned={lastCoinsEarned}
          remainingMoves={lastRemainingMoves}
          isOpen={isLevelCompleteOpen}
          onNextLevel={() => {
            if (currentLevel < 500) {
              startLevel(currentLevel + 1);
            } else {
              setScreen('LEVEL_SELECT');
            }
          }}
          onReplay={() => startLevel(currentLevel)}
          onLevelSelect={() => {
            setIsLevelCompleteOpen(false);
            setScreen('LEVEL_SELECT');
          }}
        />

        {/* 3. Game Over Modal */}
        <GameOverModal
          levelNumber={currentLevel}
          score={lastScore}
          goalDescription={lastGameOverGoal}
          isOpen={isGameOverOpen}
          hasExtraMovesInInventory={stats.powerUps.extraMoves > 0}
          onUseExtraMoves={() => {
            sound.win();
            const updated: PlayerStats = {
              ...stats,
              powerUps: {
                ...stats.powerUps,
                extraMoves: stats.powerUps.extraMoves - 1,
              },
            };
            handleUpdateStats(updated);
            setExtraMovesGranted((m) => m + 5);
            setIsGameOverOpen(false);
          }}
          onWatchAdForMoves={() => {
            handleTriggerAd('REWARDED_MOVES', () => {
              setExtraMovesGranted((m) => m + 5);
              setIsGameOverOpen(false);
            });
          }}
          onRetry={() => startLevel(currentLevel)}
          onLevelSelect={() => {
            setIsGameOverOpen(false);
            setScreen('LEVEL_SELECT');
          }}
        />

        {/* 4. Shop Modal */}
        <ShopModal
          stats={stats}
          isOpen={isShopOpen}
          onClose={() => setIsShopOpen(false)}
          onUpdateStats={handleUpdateStats}
          onWatchAd={() => {
            handleTriggerAd('REWARDED_COINS', () => {
              handleUpdateStats({
                ...stats,
                coins: stats.coins + 150,
              });
            });
          }}
        />

        {/* 5. Daily Rewards Modal */}
        <DailyRewardsModal
          stats={stats}
          isOpen={isDailyOpen}
          onClose={() => setIsDailyOpen(false)}
          onUpdateStats={handleUpdateStats}
        />

        {/* 6. Achievements Modal */}
        <AchievementsModal
          stats={stats}
          isOpen={isAchievementsOpen}
          onClose={() => setIsAchievementsOpen(false)}
        />

        {/* 7. Profile Modal */}
        <ProfileModal
          stats={stats}
          isOpen={isProfileOpen}
          onClose={() => setIsProfileOpen(false)}
          onUpdateStats={handleUpdateStats}
        />

        {/* 8. Settings Modal */}
        <SettingsModal
          stats={stats}
          isOpen={isSettingsOpen}
          onClose={() => setIsSettingsOpen(false)}
          onUpdateStats={handleUpdateStats}
          onOpenAndroidExport={() => setIsAndroidExportOpen(true)}
          onResetProgress={handleResetProgress}
        />

        {/* 9. Leaderboard Modal */}
        <LeaderboardModal
          stats={stats}
          isOpen={isLeaderboardOpen}
          onClose={() => setIsLeaderboardOpen(false)}
        />

        {/* 10. Android Export & Publishing Guide Modal */}
        <AndroidExportModal
          isOpen={isAndroidExportOpen}
          onClose={() => setIsAndroidExportOpen(false)}
        />

        {/* 11. Google AdMob Simulation Modal */}
        <AdMobModal
          type={adType}
          isOpen={adModalOpen}
          onRewardEarned={() => {
            if (onAdRewardCallback) {
              onAdRewardCallback();
            }
          }}
          onClose={() => setAdModalOpen(false)}
        />
      </div>
    </div>
  );
}
