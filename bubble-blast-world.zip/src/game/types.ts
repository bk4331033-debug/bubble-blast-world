/**
 * Bubble Blast World - Types and Interfaces
 */

export type BubbleColor = 'RED' | 'BLUE' | 'GREEN' | 'YELLOW' | 'PURPLE' | 'ORANGE';

export type SpecialBubbleType = 'NORMAL' | 'RAINBOW' | 'BOMB' | 'FIRE' | 'STONE' | 'ICE' | 'STAR_GEM' | 'SPIKE';

export interface GridBubble {
  id: string;
  row: number;
  col: number;
  color: BubbleColor;
  type: SpecialBubbleType;
  health?: number; // for ice (e.g. 1-2 hits)
  hasGem?: boolean;
}

export interface FlyingBubble {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: BubbleColor;
  type: SpecialBubbleType;
  radius: number;
  active: boolean;
}

export interface FallingBubble {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: BubbleColor;
  type: SpecialBubbleType;
  radius: number;
  alpha: number;
  rotation: number;
  vRot: number;
}

export interface Particle {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
  life: number;
  maxLife: number;
  type?: 'circle' | 'sparkle' | 'ring' | 'star';
}

export interface FloatingText {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  scale: number;
}

export type LevelGoalType = 'CLEAR_ALL' | 'RESCUE_GEMS' | 'CLEAR_CEILING';

export interface LevelConfig {
  levelNumber: number;
  worldIndex: number;
  worldName: string;
  worldColor: string;
  goalType: LevelGoalType;
  targetGemsCount: number;
  maxMoves: number;
  availableColors: BubbleColor[];
  starScores: [number, number, number]; // 1, 2, 3 stars
  rows: (GridBubble | null)[][];
}

export interface PowerUpInventory {
  rainbow: number;
  bomb: number;
  fire: number;
  aimGuide: number;
  extraMoves: number;
}

export interface PlayerStats {
  username: string;
  avatar: string;
  coins: number;
  unlockedLevel: number;
  levelStars: Record<number, number>;
  levelHighScores: Record<number, number>;
  totalBubblesPopped: number;
  totalGemsRescued: number;
  highestCombo: number;
  powerUps: PowerUpInventory;
  claimedDailyDays: number[];
  lastDailyClaimTimestamp: number;
  soundEnabled: boolean;
  musicEnabled: boolean;
  soundVolume?: number;
  musicVolume?: number;
  hapticEnabled: boolean;
  achievements: string[];
}

export interface AchievementItem {
  id: string;
  title: string;
  description: string;
  rewardCoins: number;
  icon: string;
  requirement: (stats: PlayerStats) => boolean;
}

export interface LeaderboardEntry {
  rank: number;
  username: string;
  avatar: string;
  stars: number;
  score: number;
  level: number;
  isPlayer?: boolean;
}

export type ScreenState =
  | 'MAIN_MENU'
  | 'LEVEL_SELECT'
  | 'GAMEPLAY'
  | 'PAUSE'
  | 'LEVEL_COMPLETE'
  | 'GAME_OVER'
  | 'SHOP'
  | 'DAILY_REWARDS'
  | 'ACHIEVEMENTS'
  | 'PROFILE'
  | 'SETTINGS'
  | 'LEADERBOARD'
  | 'ANDROID_EXPORT';
