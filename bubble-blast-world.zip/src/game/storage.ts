/**
 * Bubble Blast World - Player Storage, Achievements & Offline State
 */

import { AchievementItem, PlayerStats } from './types';

const STORAGE_KEY = 'bubble_blast_world_save_v1';

export const DEFAULT_AVATARS = [
  { id: 'bubble_master', name: 'Bubble Master', icon: '🔮' },
  { id: 'star_explorer', name: 'Star Explorer', icon: '⭐' },
  { id: 'gem_hunter', name: 'Gem Hunter', icon: '💎' },
  { id: 'fire_dragon', name: 'Fire Dragon', icon: '🐲' },
  { id: 'cosmic_bot', name: 'Cosmo Bot', icon: '🤖' },
  { id: 'rainbow_fairy', name: 'Rainbow Fairy', icon: '🧚' },
];

export const ACHIEVEMENTS: AchievementItem[] = [
  {
    id: 'first_win',
    title: 'First Blast',
    description: 'Complete your first level',
    rewardCoins: 50,
    icon: '🎯',
    requirement: (s) => (s.levelStars[1] || 0) > 0,
  },
  {
    id: 'bubble_popper_100',
    title: 'Bubble Buster',
    description: 'Pop 100 bubbles in total',
    rewardCoins: 100,
    icon: '🫧',
    requirement: (s) => s.totalBubblesPopped >= 100,
  },
  {
    id: 'bubble_popper_1000',
    title: 'Master Popper',
    description: 'Pop 1,000 bubbles in total',
    rewardCoins: 300,
    icon: '💥',
    requirement: (s) => s.totalBubblesPopped >= 1000,
  },
  {
    id: 'gem_rescuer_10',
    title: 'Gem Specialist',
    description: 'Rescue 10 trapped star gems',
    rewardCoins: 150,
    icon: '💎',
    requirement: (s) => s.totalGemsRescued >= 10,
  },
  {
    id: 'combo_5',
    title: 'Combo Maestro',
    description: 'Achieve a 5x or higher pop combo',
    rewardCoins: 120,
    icon: '🔥',
    requirement: (s) => s.highestCombo >= 5,
  },
  {
    id: 'world_1_clear',
    title: 'Meadow Champion',
    description: 'Reach Level 50 in Sunny Meadow',
    rewardCoins: 500,
    icon: '🌱',
    requirement: (s) => s.unlockedLevel >= 50,
  },
  {
    id: 'star_collector_30',
    title: 'Starlight Collector',
    description: 'Collect 30 total stars',
    rewardCoins: 200,
    icon: '⭐',
    requirement: (s) => Object.values(s.levelStars).reduce((a, b) => a + b, 0) >= 30,
  },
  {
    id: 'rich_blaster',
    title: 'Treasure Hoarder',
    description: 'Accumulate 1,000 coins',
    rewardCoins: 250,
    icon: '💰',
    requirement: (s) => s.coins >= 1000,
  },
];

export const DAILY_REWARDS_TABLE = [
  { day: 1, type: 'COINS', amount: 100, label: '100 Coins', icon: '🪙' },
  { day: 2, type: 'AIM_GUIDE', amount: 2, label: '2x Aim Guide', icon: '🎯' },
  { day: 3, type: 'COINS', amount: 250, label: '250 Coins', icon: '🪙' },
  { day: 4, type: 'BOMB', amount: 2, label: '2x Bomb', icon: '💣' },
  { day: 5, type: 'FIRE', amount: 2, label: '2x Fire Bubble', icon: '🔥' },
  { day: 6, type: 'RAINBOW', amount: 2, label: '2x Rainbow', icon: '🌈' },
  { day: 7, type: 'JACKPOT', amount: 1, label: '500 Coins + 2 All Power-ups', icon: '👑' },
];

export const INITIAL_STATS: PlayerStats = {
  username: 'Blaster Pilot',
  avatar: 'bubble_master',
  coins: 300,
  unlockedLevel: 1,
  levelStars: {},
  levelHighScores: {},
  totalBubblesPopped: 0,
  totalGemsRescued: 0,
  highestCombo: 0,
  powerUps: {
    rainbow: 2,
    bomb: 2,
    fire: 2,
    aimGuide: 3,
    extraMoves: 2,
  },
  claimedDailyDays: [],
  lastDailyClaimTimestamp: 0,
  soundEnabled: true,
  musicEnabled: true,
  soundVolume: 0.8,
  musicVolume: 0.5,
  hapticEnabled: true,
  achievements: [],
};

export function loadPlayerStats(): PlayerStats {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...INITIAL_STATS };
    const parsed = JSON.parse(raw);
    return {
      ...INITIAL_STATS,
      ...parsed,
      powerUps: {
        ...INITIAL_STATS.powerUps,
        ...(parsed.powerUps || {}),
      },
      levelStars: parsed.levelStars || {},
      levelHighScores: parsed.levelHighScores || {},
      claimedDailyDays: parsed.claimedDailyDays || [],
      achievements: parsed.achievements || [],
    };
  } catch (e) {
    return { ...INITIAL_STATS };
  }
}

export function savePlayerStats(stats: PlayerStats) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stats));
  } catch (e) {
    console.error('Failed to save to localStorage', e);
  }
}

export function checkNewAchievements(stats: PlayerStats): { updatedStats: PlayerStats; newlyUnlocked: AchievementItem[] } {
  const newlyUnlocked: AchievementItem[] = [];
  const currentSet = new Set(stats.achievements);
  let earnedCoins = 0;

  for (const ach of ACHIEVEMENTS) {
    if (!currentSet.has(ach.id) && ach.requirement(stats)) {
      newlyUnlocked.push(ach);
      currentSet.add(ach.id);
      earnedCoins += ach.rewardCoins;
    }
  }

  if (newlyUnlocked.length > 0) {
    const updatedStats: PlayerStats = {
      ...stats,
      coins: stats.coins + earnedCoins,
      achievements: Array.from(currentSet),
    };
    savePlayerStats(updatedStats);
    return { updatedStats, newlyUnlocked };
  }

  return { updatedStats: stats, newlyUnlocked: [] };
}
