/**
 * Bubble Blast World - Google AdMob & Monetization Architecture
 * Supports native Capacitor/Cordova Google Mobile Ads SDK and in-browser interactive testing.
 */

export interface AdMobConfig {
  appId: string;
  bannerId: string;
  interstitialId: string;
  rewardedId: string;
  isTesting: boolean;
}

// Google AdMob Official Test IDs for Android
export const DEFAULT_ADMOB_CONFIG: AdMobConfig = {
  appId: 'ca-app-pub-3940256099942544~3347511713',
  bannerId: 'ca-app-pub-3940256099942544/6300978111',
  interstitialId: 'ca-app-pub-3940256099942544/1033173712',
  rewardedId: 'ca-app-pub-3940256099942544/5224354917',
  isTesting: true,
};

export type AdType = 'REWARDED_MOVES' | 'REWARDED_COINS' | 'INTERSTITIAL';

class AdMobManager {
  private isNative: boolean = false;
  private adCount: number = 0;

  constructor() {
    this.detectEnvironment();
  }

  private detectEnvironment() {
    // Check if running inside Capacitor Android container or Cordova
    if (typeof window !== 'undefined' && ((window as any).Capacitor || (window as any).cordova)) {
      this.isNative = true;
    }
  }

  public shouldShowInterstitial(): boolean {
    this.adCount++;
    // Show interstitial every 3 levels completed to avoid intrusive spamming
    return this.adCount % 3 === 0;
  }
}

export const adMobService = new AdMobManager();
