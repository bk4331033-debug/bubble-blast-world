/**
 * Bubble Blast World - Web Audio API Procedural Sound Engine
 * Fully offline, low-latency, and responsive with volume control & debouncing.
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  private musicGainNode: GainNode | null = null;
  private sfxGainNode: GainNode | null = null;
  private masterGainNode: GainNode | null = null;
  private isMusicPlaying: boolean = false;
  private musicInterval: any = null;
  private musicBeat: number = 0;
  private lastSoundTimes: Map<string, number> = new Map();

  public soundEnabled: boolean = true;
  public musicEnabled: boolean = true;
  public sfxVolume: number = 0.8;
  public musicVolume: number = 0.5;

  constructor() {
    // AudioContext will be initialized on first user interaction
  }

  /**
   * Unlock AudioContext on user gesture for mobile browsers
   */
  public unlockAudio() {
    this.initCtx();
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  private initCtx() {
    if (!this.ctx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtxClass) {
        this.ctx = new AudioCtxClass();

        this.masterGainNode = this.ctx.createGain();
        this.masterGainNode.gain.value = 1.0;
        this.masterGainNode.connect(this.ctx.destination);

        this.sfxGainNode = this.ctx.createGain();
        this.sfxGainNode.gain.value = this.soundEnabled ? this.sfxVolume * 0.45 : 0;
        this.sfxGainNode.connect(this.masterGainNode);

        this.musicGainNode = this.ctx.createGain();
        this.musicGainNode.gain.value = this.musicEnabled ? this.musicVolume * 0.16 : 0;
        this.musicGainNode.connect(this.masterGainNode);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  /**
   * Prevents excessive overlapping of identical sound triggers within milliseconds
   */
  private canPlay(key: string, cooldownMs: number = 35): boolean {
    const now = performance.now();
    const last = this.lastSoundTimes.get(key) || 0;
    if (now - last < cooldownMs) return false;
    this.lastSoundTimes.set(key, now);
    return true;
  }

  public setVolume(sfxVol: number, musicVol: number) {
    this.sfxVolume = Math.max(0, Math.min(1, sfxVol));
    this.musicVolume = Math.max(0, Math.min(1, musicVol));

    if (this.sfxGainNode && this.ctx) {
      this.sfxGainNode.gain.setValueAtTime(
        this.soundEnabled ? this.sfxVolume * 0.45 : 0,
        this.ctx.currentTime
      );
    }
    if (this.musicGainNode && this.ctx) {
      this.musicGainNode.gain.setValueAtTime(
        this.musicEnabled ? this.musicVolume * 0.16 : 0,
        this.ctx.currentTime
      );
    }
  }

  /**
   * Crisp, fast, responsive bubble launch sound
   */
  public shoot() {
    if (!this.soundEnabled || !this.canPlay('shoot', 60)) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGainNode) return;

    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(540, t);
      osc.frequency.exponentialRampToValueAtTime(160, t + 0.08);

      gain.gain.setValueAtTime(0.4, t);
      gain.gain.exponentialRampToValueAtTime(0.005, t + 0.08);

      osc.connect(gain);
      gain.connect(this.sfxGainNode);

      osc.start(t);
      osc.stop(t + 0.08);
    } catch {}
  }

  /**
   * Pleasant subtle thud/snap when a bubble lands without matching
   */
  public stick() {
    if (!this.soundEnabled || !this.canPlay('stick', 40)) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGainNode) return;

    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(260, t);
      osc.frequency.exponentialRampToValueAtTime(110, t + 0.05);

      gain.gain.setValueAtTime(0.25, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.05);

      osc.connect(gain);
      gain.connect(this.sfxGainNode);

      osc.start(t);
      osc.stop(t + 0.05);
    } catch {}
  }

  /**
   * Satisfying, clear popping sound when 3 or more matching bubbles connect.
   * Differentiates between small groups (3) and large bubble groups (4+ or 6+).
   */
  public matchPop(bubbleCount: number, comboCount: number = 1) {
    if (!this.soundEnabled || !this.canPlay('matchPop', 40)) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGainNode) return;

    try {
      const t = this.ctx.currentTime;
      const pentatonic = [440, 493.88, 554.37, 659.25, 739.99, 880, 987.77, 1108.73];
      const noteIdx = Math.min(comboCount - 1, pentatonic.length - 1);
      const baseFreq = pentatonic[Math.max(0, noteIdx)];

      const isLargeGroup = bubbleCount >= 4;
      const isMegaGroup = bubbleCount >= 6;

      // 1. Primary Pop Snap Oscillator
      const popOsc = this.ctx.createOscillator();
      const popGain = this.ctx.createGain();

      popOsc.type = isLargeGroup ? 'sawtooth' : 'triangle';
      popOsc.frequency.setValueAtTime(baseFreq * (isLargeGroup ? 1.1 : 0.9), t);
      popOsc.frequency.exponentialRampToValueAtTime(baseFreq * 1.8, t + 0.03);
      popOsc.frequency.exponentialRampToValueAtTime(baseFreq * 0.5, t + (isLargeGroup ? 0.12 : 0.08));

      popGain.gain.setValueAtTime(isLargeGroup ? 0.55 : 0.45, t);
      popGain.gain.exponentialRampToValueAtTime(0.005, t + (isLargeGroup ? 0.12 : 0.08));

      popOsc.connect(popGain);
      popGain.connect(this.sfxGainNode);
      popOsc.start(t);
      popOsc.stop(t + (isLargeGroup ? 0.12 : 0.08));

      // 2. High crisp click burst (the air bubble cavitation snap)
      const clickOsc = this.ctx.createOscillator();
      const clickGain = this.ctx.createGain();
      clickOsc.type = 'sine';
      clickOsc.frequency.setValueAtTime(baseFreq * 2.8, t);
      clickOsc.frequency.exponentialRampToValueAtTime(180, t + 0.035);
      clickGain.gain.setValueAtTime(0.35, t);
      clickGain.gain.exponentialRampToValueAtTime(0.001, t + 0.035);

      clickOsc.connect(clickGain);
      clickGain.connect(this.sfxGainNode);
      clickOsc.start(t);
      clickOsc.stop(t + 0.035);

      // 3. For large bubble groups: rich resonance and sparkling overtone
      if (isLargeGroup) {
        const resOsc = this.ctx.createOscillator();
        const resGain = this.ctx.createGain();
        resOsc.type = 'sine';
        resOsc.frequency.setValueAtTime(baseFreq * 1.5, t + 0.02);
        resOsc.frequency.exponentialRampToValueAtTime(baseFreq * 2.5, t + 0.14);

        resGain.gain.setValueAtTime(0.3, t + 0.02);
        resGain.gain.exponentialRampToValueAtTime(0.001, t + 0.14);

        resOsc.connect(resGain);
        resGain.connect(this.sfxGainNode);
        resOsc.start(t + 0.02);
        resOsc.stop(t + 0.14);
      }

      // 4. For mega group: grand sparkling ping
      if (isMegaGroup) {
        const pingOsc = this.ctx.createOscillator();
        const pingGain = this.ctx.createGain();
        pingOsc.type = 'sine';
        pingOsc.frequency.setValueAtTime(baseFreq * 3, t + 0.04);
        pingGain.gain.setValueAtTime(0.25, t + 0.04);
        pingGain.gain.exponentialRampToValueAtTime(0.001, t + 0.2);

        pingOsc.connect(pingGain);
        pingGain.connect(this.sfxGainNode);
        pingOsc.start(t + 0.04);
        pingOsc.stop(t + 0.2);
      }
    } catch {}
  }

  /**
   * Cheerful falling sound when disconnected bubbles drop
   */
  public drop(bubbleCount: number = 1) {
    if (!this.soundEnabled || !this.canPlay('drop', 80)) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGainNode) return;

    try {
      const count = Math.min(4, Math.max(1, Math.floor(bubbleCount / 2)));
      for (let i = 0; i < count; i++) {
        const t = this.ctx.currentTime + i * 0.04;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        const startFreq = 750 - i * 90;
        osc.frequency.setValueAtTime(startFreq, t);
        osc.frequency.exponentialRampToValueAtTime(startFreq * 0.45, t + 0.12);

        gain.gain.setValueAtTime(0.32, t);
        gain.gain.exponentialRampToValueAtTime(0.005, t + 0.12);

        osc.connect(gain);
        gain.connect(this.sfxGainNode);

        osc.start(t);
        osc.stop(t + 0.12);
      }
    } catch {}
  }

  /**
   * Special sound when a power-up is activated
   */
  public powerupActivate(type: 'RAINBOW' | 'BOMB' | 'FIRE' | 'AIM' | 'MOVES') {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGainNode) return;

    try {
      const t = this.ctx.currentTime;
      if (type === 'BOMB') {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(140, t);
        osc.frequency.exponentialRampToValueAtTime(45, t + 0.25);
        gain.gain.setValueAtTime(0.6, t);
        gain.gain.exponentialRampToValueAtTime(0.01, t + 0.25);
        osc.connect(gain);
        gain.connect(this.sfxGainNode);
        osc.start(t);
        osc.stop(t + 0.25);
      } else if (type === 'FIRE') {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(850, t);
        osc.frequency.exponentialRampToValueAtTime(260, t + 0.22);
        gain.gain.setValueAtTime(0.45, t);
        gain.gain.exponentialRampToValueAtTime(0.01, t + 0.22);
        osc.connect(gain);
        gain.connect(this.sfxGainNode);
        osc.start(t);
        osc.stop(t + 0.22);
      } else if (type === 'RAINBOW') {
        const notes = [523.25, 659.25, 783.99, 1046.5];
        notes.forEach((freq, idx) => {
          const noteT = t + idx * 0.04;
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, noteT);
          gain.gain.setValueAtTime(0.28, noteT);
          gain.gain.exponentialRampToValueAtTime(0.001, noteT + 0.1);
          osc.connect(gain);
          gain.connect(this.sfxGainNode!);
          osc.start(noteT);
          osc.stop(noteT + 0.1);
        });
      } else if (type === 'AIM') {
        // High-tech laser calibration tone
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, t);
        osc.frequency.exponentialRampToValueAtTime(1760, t + 0.15);
        gain.gain.setValueAtTime(0.3, t);
        gain.gain.exponentialRampToValueAtTime(0.01, t + 0.15);
        osc.connect(gain);
        gain.connect(this.sfxGainNode);
        osc.start(t);
        osc.stop(t + 0.15);
      } else if (type === 'MOVES') {
        // Cheerful bonus chime
        [659.25, 880].forEach((freq, idx) => {
          const noteT = t + idx * 0.06;
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, noteT);
          gain.gain.setValueAtTime(0.35, noteT);
          gain.gain.exponentialRampToValueAtTime(0.005, noteT + 0.14);
          osc.connect(gain);
          gain.connect(this.sfxGainNode!);
          osc.start(noteT);
          osc.stop(noteT + 0.14);
        });
      }
    } catch {}
  }

  public bomb() {
    this.powerupActivate('BOMB');
  }

  public fire() {
    this.powerupActivate('FIRE');
  }

  public rainbow() {
    this.powerupActivate('RAINBOW');
  }

  public gem() {
    if (!this.soundEnabled || !this.canPlay('gem', 50)) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGainNode) return;

    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(1174.66, t);
      osc.frequency.exponentialRampToValueAtTime(1760.0, t + 0.12);

      gain.gain.setValueAtTime(0.35, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.16);

      osc.connect(gain);
      gain.connect(this.sfxGainNode);

      osc.start(t);
      osc.stop(t + 0.16);
    } catch {}
  }

  public click() {
    if (!this.soundEnabled || !this.canPlay('click', 30)) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGainNode) return;

    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(750, t);
      osc.frequency.exponentialRampToValueAtTime(420, t + 0.025);

      gain.gain.setValueAtTime(0.2, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.025);

      osc.connect(gain);
      gain.connect(this.sfxGainNode);

      osc.start(t);
      osc.stop(t + 0.025);
    } catch {}
  }

  /**
   * Cheerful, triumphant sound when a level is completed
   */
  public win() {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGainNode) return;

    try {
      const melody = [
        { f: 523.25, d: 0.09 }, // C5
        { f: 659.25, d: 0.09 }, // E5
        { f: 783.99, d: 0.09 }, // G5
        { f: 1046.5, d: 0.24 }, // C6
      ];

      let curT = this.ctx.currentTime;
      melody.forEach(note => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(note.f, curT);

        gain.gain.setValueAtTime(0.42, curT);
        gain.gain.exponentialRampToValueAtTime(0.01, curT + note.d);

        osc.connect(gain);
        gain.connect(this.sfxGainNode!);

        osc.start(curT);
        osc.stop(curT + note.d);
        curT += note.d + 0.015;
      });
    } catch {}
  }

  /**
   * Game over sound when the player loses
   */
  public lose() {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGainNode) return;

    try {
      const notes = [
        { f: 493.88, d: 0.12 }, // B4
        { f: 466.16, d: 0.12 }, // Bb4
        { f: 440.0, d: 0.12 },  // A4
        { f: 392.0, d: 0.22 },  // G4
      ];

      let curT = this.ctx.currentTime;
      notes.forEach(note => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(note.f, curT);

        gain.gain.setValueAtTime(0.32, curT);
        gain.gain.exponentialRampToValueAtTime(0.01, curT + note.d);

        osc.connect(gain);
        gain.connect(this.sfxGainNode!);

        osc.start(curT);
        osc.stop(curT + note.d);
        curT += note.d;
      });
    } catch {}
  }

  public startMusic() {
    if (!this.musicEnabled) return;
    this.initCtx();
    if (!this.ctx || !this.musicGainNode) return;
    if (this.isMusicPlaying) return;

    this.isMusicPlaying = true;
    this.musicBeat = 0;

    const melodySeq = [
      523.25, 0, 659.25, 783.99,
      659.25, 523.25, 0, 880.0,
      783.99, 659.25, 523.25, 0,
      440.0, 523.25, 659.25, 783.99,
    ];

    const bassSeq = [
      130.81, 130.81, 164.81, 164.81,
      174.61, 174.61, 196.00, 196.00,
    ];

    const stepMs = 280;
    this.musicInterval = setInterval(() => {
      if (!this.musicEnabled || !this.ctx || !this.musicGainNode) {
        this.stopMusic();
        return;
      }

      const note = melodySeq[this.musicBeat % melodySeq.length];
      const bass = bassSeq[Math.floor(this.musicBeat / 2) % bassSeq.length];
      const t = this.ctx.currentTime;

      if (note > 0) {
        try {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(note, t);
          gain.gain.setValueAtTime(0.12, t);
          gain.gain.exponentialRampToValueAtTime(0.001, t + 0.22);
          osc.connect(gain);
          gain.connect(this.musicGainNode);
          osc.start(t);
          osc.stop(t + 0.22);
        } catch {}
      }

      if (this.musicBeat % 2 === 0) {
        try {
          const bOsc = this.ctx.createOscillator();
          const bGain = this.ctx.createGain();
          bOsc.type = 'triangle';
          bOsc.frequency.setValueAtTime(bass, t);
          bGain.gain.setValueAtTime(0.18, t);
          bGain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
          bOsc.connect(bGain);
          bGain.connect(this.musicGainNode);
          bOsc.start(t);
          bOsc.stop(t + 0.35);
        } catch {}
      }

      this.musicBeat++;
    }, stepMs);
  }

  public stopMusic() {
    this.isMusicPlaying = false;
    if (this.musicInterval) {
      clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
  }

  public updateSettings(sound: boolean, music: boolean, sfxVol?: number, musicVol?: number) {
    this.soundEnabled = sound;
    this.musicEnabled = music;
    if (sfxVol !== undefined) this.sfxVolume = sfxVol;
    if (musicVol !== undefined) this.musicVolume = musicVol;

    if (this.ctx) {
      if (this.sfxGainNode) {
        this.sfxGainNode.gain.setValueAtTime(
          this.soundEnabled ? this.sfxVolume * 0.45 : 0,
          this.ctx.currentTime
        );
      }
      if (this.musicGainNode) {
        this.musicGainNode.gain.setValueAtTime(
          this.musicEnabled ? this.musicVolume * 0.16 : 0,
          this.ctx.currentTime
        );
      }
    }

    if (!music) {
      this.stopMusic();
    } else if (!this.isMusicPlaying) {
      this.startMusic();
    }
  }
}

export const sound = new SoundEngine();
