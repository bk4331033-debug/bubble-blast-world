/**
 * Bubble Blast World - High Performance Canvas Renderer
 * Renders glossy 3D bubbles, particles, trajectory, and effects
 */

import { BubbleColor, FallingBubble, FlyingBubble, FloatingText, GridBubble, Particle, SpecialBubbleType } from './types';

// Distinctive color palettes with light and dark specular highlights
export const COLOR_MAP: Record<BubbleColor, { main: string; light: string; dark: string; glow: string; symbol: string }> = {
  RED: {
    main: '#ef4444',
    light: '#fca5a5',
    dark: '#b91c1c',
    glow: 'rgba(239, 68, 68, 0.45)',
    symbol: '◆',
  },
  BLUE: {
    main: '#3b82f6',
    light: '#93c5fd',
    dark: '#1d4ed8',
    glow: 'rgba(59, 130, 246, 0.45)',
    symbol: '▲',
  },
  GREEN: {
    main: '#10b981',
    light: '#6ee7b7',
    dark: '#047857',
    glow: 'rgba(16, 185, 129, 0.45)',
    symbol: '●',
  },
  YELLOW: {
    main: '#f59e0b',
    light: '#fde68a',
    dark: '#b45309',
    glow: 'rgba(245, 158, 11, 0.45)',
    symbol: '★',
  },
  PURPLE: {
    main: '#8b5cf6',
    light: '#c4b5fd',
    dark: '#6d28d9',
    glow: 'rgba(139, 92, 246, 0.45)',
    symbol: '♥',
  },
  ORANGE: {
    main: '#f97316',
    light: '#fdba74',
    dark: '#c2410c',
    glow: 'rgba(249, 115, 22, 0.45)',
    symbol: '✦',
  },
};

export function drawGlossyBubble(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  radius: number,
  color: BubbleColor,
  type: SpecialBubbleType = 'NORMAL',
  alpha: number = 1,
  rotation: number = 0
) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(x, y);
  if (rotation !== 0) {
    ctx.rotate(rotation);
  }

  const palette = COLOR_MAP[color] || COLOR_MAP.RED;

  // 1. Rainbow Bubble
  if (type === 'RAINBOW') {
    const rainbowGrad = ctx.createLinearGradient(-radius, -radius, radius, radius);
    rainbowGrad.addColorStop(0, '#f43f5e');
    rainbowGrad.addColorStop(0.25, '#eab308');
    rainbowGrad.addColorStop(0.5, '#10b981');
    rainbowGrad.addColorStop(0.75, '#06b6d4');
    rainbowGrad.addColorStop(1, '#8b5cf6');

    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, Math.PI * 2);
    ctx.fillStyle = rainbowGrad;
    ctx.fill();

    // Swirling iridescent sheen
    ctx.beginPath();
    ctx.ellipse(-radius * 0.25, -radius * 0.25, radius * 0.55, radius * 0.35, -Math.PI / 4, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
    ctx.fill();

    // Rainbow star icon
    ctx.fillStyle = '#ffffff';
    ctx.font = `bold ${Math.round(radius * 0.9)}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('🌈', 0, 1);
    ctx.restore();
    return;
  }

  // 2. Bomb Bubble
  if (type === 'BOMB') {
    // Dark metallic bomb sphere
    const bombGrad = ctx.createRadialGradient(-radius * 0.3, -radius * 0.3, radius * 0.1, 0, 0, radius);
    bombGrad.addColorStop(0, '#64748b');
    bombGrad.addColorStop(0.6, '#1e293b');
    bombGrad.addColorStop(1, '#090d16');

    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, Math.PI * 2);
    ctx.fillStyle = bombGrad;
    ctx.fill();

    // Glowing fuse & skull/bomb mark
    ctx.beginPath();
    ctx.arc(0, 0, radius * 0.45, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(239, 68, 68, 0.35)';
    ctx.fill();

    ctx.fillStyle = '#ef4444';
    ctx.font = `bold ${Math.round(radius * 0.9)}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('💣', 0, 0);
    ctx.restore();
    return;
  }

  // 3. Fire Bubble
  if (type === 'FIRE') {
    const fireGrad = ctx.createRadialGradient(0, 0, radius * 0.2, 0, 0, radius);
    fireGrad.addColorStop(0, '#fef08a');
    fireGrad.addColorStop(0.5, '#f97316');
    fireGrad.addColorStop(1, '#b91c1c');

    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, Math.PI * 2);
    ctx.fillStyle = fireGrad;
    ctx.fill();

    // Flame emoji
    ctx.fillStyle = '#ffffff';
    ctx.font = `bold ${Math.round(radius * 0.95)}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('🔥', 0, 0);
    ctx.restore();
    return;
  }

  // 4. Stone Bubble (Obstacle)
  if (type === 'STONE') {
    const stoneGrad = ctx.createRadialGradient(-radius * 0.3, -radius * 0.3, radius * 0.1, 0, 0, radius);
    stoneGrad.addColorStop(0, '#94a3b8');
    stoneGrad.addColorStop(0.7, '#475569');
    stoneGrad.addColorStop(1, '#1e293b');

    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, Math.PI * 2);
    ctx.fillStyle = stoneGrad;
    ctx.fill();

    // Stone cracks
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(-radius * 0.5, -radius * 0.2);
    ctx.lineTo(0, 0);
    ctx.lineTo(radius * 0.4, -radius * 0.4);
    ctx.moveTo(0, 0);
    ctx.lineTo(radius * 0.2, radius * 0.5);
    ctx.stroke();

    ctx.fillStyle = '#cbd5e1';
    ctx.font = `bold ${Math.round(radius * 0.8)}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('🪨', 0, 0);
    ctx.restore();
    return;
  }

  // 5. Standard Glossy Sphere Base
  const grad = ctx.createRadialGradient(
    -radius * 0.35,
    -radius * 0.35,
    radius * 0.1,
    0,
    0,
    radius
  );
  grad.addColorStop(0, palette.light);
  grad.addColorStop(0.4, palette.main);
  grad.addColorStop(1, palette.dark);

  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, Math.PI * 2);
  ctx.fillStyle = grad;
  ctx.fill();

  // Subtle outer shadow ring
  ctx.strokeStyle = palette.dark;
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Primary top highlight (glossy bounce reflection)
  ctx.beginPath();
  ctx.ellipse(
    -radius * 0.3,
    -radius * 0.35,
    radius * 0.42,
    radius * 0.24,
    -Math.PI / 4,
    0,
    Math.PI * 2
  );
  ctx.fillStyle = 'rgba(255, 255, 255, 0.68)';
  ctx.fill();

  // Secondary lower crescent reflection
  ctx.beginPath();
  ctx.ellipse(
    radius * 0.25,
    radius * 0.3,
    radius * 0.3,
    radius * 0.12,
    -Math.PI / 4,
    0,
    Math.PI * 2
  );
  ctx.fillStyle = 'rgba(255, 255, 255, 0.22)';
  ctx.fill();

  // Accessible center symbol for color blind distinction
  if (type === 'NORMAL') {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
    ctx.font = `600 ${Math.round(radius * 0.6)}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(palette.symbol, 0, 1);
  }

  // Special Overlays: Ice
  if (type === 'ICE') {
    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(224, 242, 254, 0.65)';
    ctx.fill();

    ctx.strokeStyle = '#bae6fd';
    ctx.lineWidth = 2.5;
    ctx.stroke();

    ctx.fillStyle = '#0284c7';
    ctx.font = `bold ${Math.round(radius * 0.8)}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('❄️', 0, 0);
  }

  // Special Overlays: Star Gem (Goal Rescue)
  if (type === 'STAR_GEM') {
    ctx.fillStyle = '#ffffff';
    ctx.font = `bold ${Math.round(radius * 0.85)}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('💎', 0, 0);
  }

  // Special Overlays: Spike
  if (type === 'SPIKE') {
    ctx.fillStyle = '#334155';
    ctx.font = `bold ${Math.round(radius * 0.85)}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('⚙️', 0, 0);
  }

  ctx.restore();
}

export function drawTrajectory(
  ctx: CanvasRenderingContext2D,
  startX: number,
  startY: number,
  angleRad: number,
  canvasWidth: number,
  bubbleRadius: number,
  maxBounces: number = 2,
  isSuperAim: boolean = false,
  gridCheckCollision?: (x: number, y: number) => boolean
) {
  ctx.save();
  let cx = startX;
  let cy = startY;
  let vx = Math.cos(angleRad);
  let vy = Math.sin(angleRad);

  const stepDist = 8;
  const dotSpacing = isSuperAim ? 12 : 16;
  let distanceCovered = 0;
  let bounces = 0;
  let targetPoint: { x: number; y: number } | null = null;

  ctx.fillStyle = isSuperAim ? '#38bdf8' : 'rgba(255, 255, 255, 0.75)';

  while (cy > bubbleRadius && bounces <= maxBounces) {
    cx += vx * stepDist;
    cy += vy * stepDist;
    distanceCovered += stepDist;

    // Check side wall bounce
    if (cx <= bubbleRadius) {
      cx = bubbleRadius;
      vx = -vx;
      bounces++;
    } else if (cx >= canvasWidth - bubbleRadius) {
      cx = canvasWidth - bubbleRadius;
      vx = -vx;
      bounces++;
    }

    // Check grid collision
    if (gridCheckCollision && gridCheckCollision(cx, cy)) {
      targetPoint = { x: cx, y: cy };
      break;
    }

    // Ceiling reached
    if (cy <= bubbleRadius) {
      targetPoint = { x: cx, y: cy };
      break;
    }

    // Draw trajectory dots
    if (distanceCovered % dotSpacing < stepDist) {
      const dotRadius = isSuperAim ? 3.5 : 2.5;
      ctx.beginPath();
      ctx.arc(cx, cy, dotRadius, 0, Math.PI * 2);
      ctx.fill();

      if (isSuperAim) {
        ctx.beginPath();
        ctx.arc(cx, cy, dotRadius * 2, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(56, 189, 248, 0.25)';
        ctx.fill();
        ctx.fillStyle = '#38bdf8';
      }
    }
  }

  // Draw target landing reticle
  if (targetPoint) {
    ctx.strokeStyle = isSuperAim ? '#38bdf8' : 'rgba(255, 255, 255, 0.65)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(targetPoint.x, targetPoint.y, bubbleRadius * 0.9, 0, Math.PI * 2);
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(targetPoint.x, targetPoint.y, 4, 0, Math.PI * 2);
    ctx.fillStyle = isSuperAim ? '#38bdf8' : '#ffffff';
    ctx.fill();
  }

  ctx.restore();
}

export function drawParticles(ctx: CanvasRenderingContext2D, particles: Particle[]) {
  ctx.save();
  for (const p of particles) {
    ctx.globalAlpha = p.alpha;
    ctx.fillStyle = p.color;

    if (p.type === 'star') {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    } else if (p.type === 'ring') {
      ctx.strokeStyle = p.color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.stroke();
    } else {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.restore();
}

export function drawFloatingTexts(ctx: CanvasRenderingContext2D, texts: FloatingText[]) {
  ctx.save();
  for (const item of texts) {
    ctx.globalAlpha = item.alpha;
    ctx.font = `bold ${Math.round(20 * item.scale)}px 'Fredoka', cursive, sans-serif`;
    ctx.fillStyle = item.color;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(0, 0, 0, 0.7)';
    ctx.shadowBlur = 6;
    ctx.fillText(item.text, item.x, item.y);
  }
  ctx.restore();
}
