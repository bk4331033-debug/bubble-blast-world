/**
 * Bubble Blast World - 500 Level System & Deterministic Procedural Generator
 */

import { BubbleColor, GridBubble, LevelConfig, LevelGoalType, SpecialBubbleType } from './types';

export const WORLDS = [
  { index: 1, name: 'Sunny Meadow', color: 'from-amber-400 to-emerald-500', minLevel: 1, maxLevel: 50, icon: '🌱' },
  { index: 2, name: 'Crystal Cavern', color: 'from-cyan-400 to-blue-600', minLevel: 51, maxLevel: 100, icon: '💎' },
  { index: 3, name: 'Coral Reef', color: 'from-teal-400 to-indigo-600', minLevel: 101, maxLevel: 150, icon: '🪸' },
  { index: 4, name: 'Mystic Forest', color: 'from-emerald-500 to-teal-700', minLevel: 151, maxLevel: 200, icon: '🌲' },
  { index: 5, name: 'Sunset Dunes', color: 'from-orange-400 to-rose-600', minLevel: 201, maxLevel: 250, icon: '🏜️' },
  { index: 6, name: 'Frost Peaks', color: 'from-sky-300 to-indigo-500', minLevel: 251, maxLevel: 300, icon: '❄️' },
  { index: 7, name: 'Volcanic Forge', color: 'from-red-500 to-amber-700', minLevel: 301, maxLevel: 350, icon: '🌋' },
  { index: 8, name: 'Enchanted Grove', color: 'from-fuchsia-400 to-purple-700', minLevel: 351, maxLevel: 400, icon: '🔮' },
  { index: 9, name: 'Sky Citadel', color: 'from-blue-400 to-violet-600', minLevel: 401, maxLevel: 450, icon: '🏰' },
  { index: 10, name: 'Starlight Cosmos', color: 'from-violet-500 to-pink-600', minLevel: 451, maxLevel: 500, icon: '✨' },
];

export const ALL_COLORS: BubbleColor[] = ['RED', 'BLUE', 'GREEN', 'YELLOW', 'PURPLE', 'ORANGE'];

// Linear Congruential Generator for deterministic level generation
function pseudoRandom(seed: number) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

export function getLevelConfig(levelNumber: number): LevelConfig {
  const clampedLevel = Math.max(1, Math.min(500, Math.floor(levelNumber)));
  const rand = pseudoRandom(clampedLevel * 9973 + 12345);

  const world = WORLDS.find(w => clampedLevel >= w.minLevel && clampedLevel <= w.maxLevel) || WORLDS[0];

  // Number of active colors scales with level
  let colorCount = 3;
  if (clampedLevel > 20) colorCount = 4;
  if (clampedLevel > 80) colorCount = 5;
  if (clampedLevel > 220) colorCount = 6;

  const availableColors = ALL_COLORS.slice(0, colorCount);

  // Goal types based on level patterns
  let goalType: LevelGoalType = 'CLEAR_ALL';
  if (clampedLevel % 3 === 0 && clampedLevel >= 15) {
    goalType = 'RESCUE_GEMS';
  } else if (clampedLevel % 5 === 0 && clampedLevel >= 25) {
    goalType = 'CLEAR_CEILING';
  }

  // Row count scales from 5 to 9 initial rows
  const rowCount = Math.min(10, 5 + Math.floor(clampedLevel / 70));
  const colsPerRowEven = 8;
  const colsPerRowOdd = 7;

  let gemsCount = 0;
  const rows: (GridBubble | null)[][] = [];

  // Generate pattern templates based on level mod
  const patternType = clampedLevel % 6;

  for (let r = 0; r < rowCount; r++) {
    const isOdd = r % 2 === 1;
    const maxCols = isOdd ? colsPerRowOdd : colsPerRowEven;
    const rowList: (GridBubble | null)[] = [];

    for (let c = 0; c < maxCols; c++) {
      let isPresent = true;

      // Pattern carving
      if (patternType === 1 && r > 2) {
        // V shape or inverted triangle
        if (c < Math.floor(r / 2) || c >= maxCols - Math.floor(r / 2)) {
          isPresent = rand() > 0.35;
        }
      } else if (patternType === 2 && r > 1) {
        // Checkerboard gaps
        if ((r + c) % 3 === 0) {
          isPresent = rand() > 0.4;
        }
      } else if (patternType === 3) {
        // Pillars or stripes
        if (c === 2 || c === 5) {
          isPresent = true;
        }
      }

      if (!isPresent) {
        rowList.push(null);
        continue;
      }

      // Pick color with clustering tendency
      let color: BubbleColor;
      if (c > 0 && rowList[c - 1] && rand() < 0.55) {
        // Cluster with left neighbor
        color = rowList[c - 1]!.color;
      } else if (r > 0 && rows[r - 1][c] && rand() < 0.45) {
        // Cluster with top neighbor
        color = rows[r - 1][c]!.color;
      } else {
        color = availableColors[Math.floor(rand() * availableColors.length)];
      }

      // Special obstacle bubbles
      let type: SpecialBubbleType = 'NORMAL';
      let hasGem = false;

      // Gem placement
      if (goalType === 'RESCUE_GEMS') {
        const gemChance = clampedLevel > 200 ? 0.12 : 0.15;
        if (rand() < gemChance && r >= 2) {
          hasGem = true;
          type = 'STAR_GEM';
          gemsCount++;
        }
      }

      // Ice bubbles (appear in World 2+)
      if (type === 'NORMAL' && clampedLevel >= 40 && rand() < (clampedLevel > 150 ? 0.12 : 0.08)) {
        type = 'ICE';
      }

      // Stone bubbles (appear in World 3+)
      if (type === 'NORMAL' && clampedLevel >= 90 && rand() < (clampedLevel > 250 ? 0.09 : 0.05)) {
        type = 'STONE';
      }

      // Spike bubbles (World 4+)
      if (type === 'NORMAL' && clampedLevel >= 150 && rand() < 0.04) {
        type = 'SPIKE';
      }

      rowList.push({
        id: `bubble-${r}-${c}-${Math.floor(rand() * 10000)}`,
        row: r,
        col: c,
        color,
        type,
        hasGem,
        health: type === 'ICE' ? 1 : undefined,
      });
    }

    rows.push(rowList);
  }

  // Ensure rescue gems has at least 3 gems
  if (goalType === 'RESCUE_GEMS' && gemsCount < 3) {
    for (let r = 2; r < rowCount && gemsCount < 3; r++) {
      for (let c = 1; c < rows[r].length && gemsCount < 3; c++) {
        const bubble = rows[r][c];
        if (bubble && bubble.type === 'NORMAL') {
          bubble.type = 'STAR_GEM';
          bubble.hasGem = true;
          gemsCount++;
        }
      }
    }
  }

  // Moves calculation: base 26 - 38 moves depending on difficulty
  const totalBubbleCount = rows.flat().filter(Boolean).length;
  const baseMoves = Math.max(18, Math.min(42, Math.round(totalBubbleCount * 0.45) + 6));
  // High levels get slightly tighter moves
  const movePenalty = Math.min(6, Math.floor(clampedLevel / 80));
  const maxMoves = Math.max(16, baseMoves - movePenalty);

  // Calibrate score thresholds
  const oneStar = totalBubbleCount * 120;
  const twoStar = Math.round(oneStar * 1.6);
  const threeStar = Math.round(oneStar * 2.4);

  return {
    levelNumber: clampedLevel,
    worldIndex: world.index,
    worldName: world.name,
    worldColor: world.color,
    goalType,
    targetGemsCount: goalType === 'RESCUE_GEMS' ? gemsCount : 0,
    maxMoves,
    availableColors,
    starScores: [oneStar, twoStar, threeStar],
    rows,
  };
}
