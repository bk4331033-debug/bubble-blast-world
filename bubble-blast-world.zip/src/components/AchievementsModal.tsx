/**
 * Bubble Blast World - Achievements Modal
 */

import React from 'react';
import { X, Trophy, Check, Coins } from 'lucide-react';
import { ACHIEVEMENTS } from '../game/storage';
import { PlayerStats } from '../game/types';
import { sound } from '../game/sound';

interface AchievementsModalProps {
  stats: PlayerStats;
  isOpen: boolean;
  onClose: () => void;
}

export const AchievementsModal: React.FC<AchievementsModalProps> = ({
  stats,
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const unlockedSet = new Set(stats.achievements);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="relative w-full max-w-md max-h-[90vh] overflow-hidden rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-slate-950/90 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Trophy className="w-6 h-6 text-amber-400" />
            <h2 className="text-xl font-bold text-white font-bubble">Achievements</h2>
          </div>

          <button
            onClick={() => {
              sound.click();
              onClose();
            }}
            className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Stats strip */}
        <div className="px-5 py-3 bg-slate-950/40 border-b border-slate-800 text-xs text-slate-300 flex items-center justify-between">
          <span>Unlocked: {unlockedSet.size} / {ACHIEVEMENTS.length}</span>
          <span className="text-amber-400 font-bold font-mono">
            {unlockedSet.size === ACHIEVEMENTS.length ? '100% Completed! 🎉' : `${Math.round((unlockedSet.size / ACHIEVEMENTS.length) * 100)}%`}
          </span>
        </div>

        {/* Achievement List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {ACHIEVEMENTS.map((ach) => {
            const isUnlocked = unlockedSet.has(ach.id);

            return (
              <div
                key={ach.id}
                className={`flex items-center justify-between p-3.5 rounded-2xl border transition-all ${
                  isUnlocked
                    ? 'bg-slate-800/80 border-amber-500/30 text-white shadow-md'
                    : 'bg-slate-950/50 border-slate-800 text-slate-400 opacity-75'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`text-2xl p-2 rounded-xl ${isUnlocked ? 'bg-amber-500/20' : 'bg-slate-800'}`}>
                    {ach.icon}
                  </div>
                  <div>
                    <div className="font-bold text-sm text-white flex items-center gap-2">
                      <span>{ach.title}</span>
                      {isUnlocked && (
                        <span className="bg-emerald-500/20 text-emerald-400 text-[10px] px-2 py-0.5 rounded font-bold border border-emerald-500/30">
                          Completed
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-slate-400">{ach.description}</div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-300 font-bold text-xs font-mono">
                  <Coins className="w-3.5 h-3.5 text-amber-400" />
                  <span>+{ach.rewardCoins}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
