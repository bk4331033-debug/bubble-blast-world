/**
 * Bubble Blast World - Main Menu Screen
 */

import React from 'react';
import { Play, Map, ShoppingBag, Calendar, Trophy, Globe, Settings, Coins, Star, Smartphone } from 'lucide-react';
import { PlayerStats } from '../game/types';
import { DEFAULT_AVATARS } from '../game/storage';
import { sound } from '../game/sound';

interface MainMenuProps {
  stats: PlayerStats;
  onPlay: () => void;
  onOpenLevelSelect: () => void;
  onOpenShop: () => void;
  onOpenDailyRewards: () => void;
  onOpenAchievements: () => void;
  onOpenLeaderboard: () => void;
  onOpenProfile: () => void;
  onOpenSettings: () => void;
  onOpenAndroidExport: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  stats,
  onPlay,
  onOpenLevelSelect,
  onOpenShop,
  onOpenDailyRewards,
  onOpenAchievements,
  onOpenLeaderboard,
  onOpenProfile,
  onOpenSettings,
  onOpenAndroidExport,
}) => {
  const currentAvatar = DEFAULT_AVATARS.find((a) => a.id === stats.avatar) || DEFAULT_AVATARS[0];
  const totalStars = Object.values(stats.levelStars).reduce((acc, curr) => acc + curr, 0);

  // Check if daily reward is available today
  const ONE_DAY_MS = 24 * 60 * 60 * 1000;
  const isDailyRewardAvailable =
    stats.lastDailyClaimTimestamp === 0 || Date.now() - stats.lastDailyClaimTimestamp >= ONE_DAY_MS;

  return (
    <div className="relative flex flex-col h-full w-full select-none overflow-hidden justify-between p-4">
      {/* Top Status Bar */}
      <div className="flex items-center justify-between w-full z-10 pt-1">
        {/* User Profile Capsule */}
        <button
          onClick={() => {
            sound.click();
            onOpenProfile();
          }}
          className="flex items-center gap-2 p-1.5 pr-3 bg-slate-900/80 backdrop-blur-md border border-white/10 rounded-full hover:bg-slate-800/90 active:scale-95 transition-all shadow-md"
        >
          <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-lg border border-indigo-400">
            {currentAvatar.icon}
          </div>
          <div className="text-left">
            <div className="text-xs font-bold text-white leading-none font-bubble">
              {stats.username}
            </div>
            <div className="text-[10px] text-amber-300 font-semibold flex items-center gap-0.5 mt-0.5">
              <Star className="w-2.5 h-2.5 fill-current" />
              <span>{totalStars}</span>
            </div>
          </div>
        </button>

        {/* Coins & Settings */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              sound.click();
              onOpenShop();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900/80 backdrop-blur-md border border-amber-500/30 rounded-full hover:bg-slate-800/90 active:scale-95 transition-all shadow-md"
          >
            <Coins className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold text-amber-300 font-mono">
              {stats.coins.toLocaleString()}
            </span>
          </button>

          <button
            onClick={() => {
              sound.click();
              onOpenSettings();
            }}
            className="p-2 bg-slate-900/80 backdrop-blur-md border border-white/10 rounded-full hover:bg-slate-800/90 active:scale-95 transition-all text-slate-300 hover:text-white shadow-md"
            title="Settings"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Hero Logo Area */}
      <div className="flex-1 flex flex-col items-center justify-center z-10 my-auto py-2">
        <div className="relative w-64 h-64 sm:w-72 sm:h-72 drop-shadow-[0_12px_24px_rgba(0,0,0,0.6)] animate-pulse transition-all">
          <img
            src="/src/assets/images/bubble_blast_world_logo_1793378031979.jpg"
            alt="Bubble Blast World Logo"
            className="w-full h-full object-contain rounded-3xl"
          />
        </div>

        <div className="mt-1 px-4 py-1 bg-indigo-950/70 border border-indigo-400/30 rounded-full text-xs font-bold text-indigo-200 backdrop-blur-sm">
          500 Puzzle Levels · 10 Worlds
        </div>
      </div>

      {/* Main Action CTAs */}
      <div className="w-full max-w-sm mx-auto space-y-3 z-10 pb-2">
        {/* Play Button */}
        <button
          onClick={() => {
            sound.click();
            onPlay();
          }}
          className="w-full py-4 bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-500 hover:from-emerald-400 hover:to-teal-300 active:scale-98 text-slate-950 font-black text-xl rounded-2xl shadow-[0_6px_0_#065f46,0_12px_24px_rgba(16,185,129,0.4)] flex items-center justify-center gap-3 transition-all font-bubble uppercase tracking-wider border border-emerald-300/40"
        >
          <Play className="w-7 h-7 fill-slate-950 text-slate-950" />
          <span>Play Level {stats.unlockedLevel}</span>
        </button>

        {/* Secondary Navigation Grid */}
        <div className="grid grid-cols-4 gap-2">
          {/* Level Map */}
          <button
            onClick={() => {
              sound.click();
              onOpenLevelSelect();
            }}
            className="flex flex-col items-center justify-center p-2.5 bg-slate-900/85 hover:bg-slate-800/90 active:scale-95 rounded-2xl border border-white/10 shadow-lg text-slate-200 transition-all"
          >
            <Map className="w-5 h-5 text-sky-400 mb-1" />
            <span className="text-[10px] font-bold">Levels</span>
          </button>

          {/* Daily Rewards */}
          <button
            onClick={() => {
              sound.click();
              onOpenDailyRewards();
            }}
            className="relative flex flex-col items-center justify-center p-2.5 bg-slate-900/85 hover:bg-slate-800/90 active:scale-95 rounded-2xl border border-white/10 shadow-lg text-slate-200 transition-all"
          >
            <Calendar className="w-5 h-5 text-emerald-400 mb-1" />
            <span className="text-[10px] font-bold">Daily</span>
            {isDailyRewardAvailable && (
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-rose-500 rounded-full border-2 border-slate-900 animate-ping" />
            )}
            {isDailyRewardAvailable && (
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-rose-500 rounded-full border-2 border-slate-900" />
            )}
          </button>

          {/* Blast Shop */}
          <button
            onClick={() => {
              sound.click();
              onOpenShop();
            }}
            className="flex flex-col items-center justify-center p-2.5 bg-slate-900/85 hover:bg-slate-800/90 active:scale-95 rounded-2xl border border-white/10 shadow-lg text-slate-200 transition-all"
          >
            <ShoppingBag className="w-5 h-5 text-amber-400 mb-1" />
            <span className="text-[10px] font-bold">Shop</span>
          </button>

          {/* Achievements */}
          <button
            onClick={() => {
              sound.click();
              onOpenAchievements();
            }}
            className="flex flex-col items-center justify-center p-2.5 bg-slate-900/85 hover:bg-slate-800/90 active:scale-95 rounded-2xl border border-white/10 shadow-lg text-slate-200 transition-all"
          >
            <Trophy className="w-5 h-5 text-purple-400 mb-1" />
            <span className="text-[10px] font-bold">Badges</span>
          </button>
        </div>

        {/* Global Leaderboards & Android Info Banner */}
        <div className="flex gap-2">
          <button
            onClick={() => {
              sound.click();
              onOpenLeaderboard();
            }}
            className="flex-1 py-2 bg-slate-900/80 hover:bg-slate-800/90 active:scale-95 rounded-xl border border-white/10 flex items-center justify-center gap-1.5 text-xs font-bold text-slate-300 transition-all"
          >
            <Globe className="w-3.5 h-3.5 text-sky-400" />
            <span>Leaderboard</span>
          </button>

          <button
            onClick={() => {
              sound.click();
              onOpenAndroidExport();
            }}
            className="flex-1 py-2 bg-slate-900/80 hover:bg-slate-800/90 active:scale-95 rounded-xl border border-white/10 flex items-center justify-center gap-1.5 text-xs font-bold text-emerald-400 transition-all"
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
            <span>Android APK</span>
          </button>
        </div>
      </div>
    </div>
  );
};
