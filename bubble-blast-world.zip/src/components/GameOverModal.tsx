/**
 * Bubble Blast World - Game Over Modal
 */

import React from 'react';
import { RotateCcw, Map, Video, Plus, Frown } from 'lucide-react';
import { sound } from '../game/sound';

interface GameOverModalProps {
  levelNumber: number;
  score: number;
  goalDescription: string;
  isOpen: boolean;
  hasExtraMovesInInventory: boolean;
  onUseExtraMoves: () => void;
  onWatchAdForMoves: () => void;
  onRetry: () => void;
  onLevelSelect: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  levelNumber,
  score,
  goalDescription,
  isOpen,
  hasExtraMovesInInventory,
  onUseExtraMoves,
  onWatchAdForMoves,
  onRetry,
  onLevelSelect,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md">
      <div className="relative w-full max-w-sm overflow-hidden rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl flex flex-col items-center p-6 text-center animate-in fade-in zoom-in-95 duration-200">
        <div className="w-14 h-14 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mb-3 border border-rose-500/30">
          <Frown className="w-8 h-8" />
        </div>

        <span className="text-xs font-bold tracking-widest text-rose-400 uppercase mb-1">
          Level {levelNumber}
        </span>
        <h2 className="text-2xl font-extrabold text-white font-bubble mb-2">
          Out of Moves!
        </h2>
        <p className="text-xs text-slate-400 mb-5">
          Goal: <span className="text-slate-200 font-semibold">{goalDescription}</span>
        </p>

        {/* Rescue Actions */}
        <div className="w-full space-y-2 mb-5">
          {/* Watch Ad for +5 Moves */}
          <button
            onClick={() => {
              sound.click();
              onWatchAdForMoves();
            }}
            className="w-full py-3 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 active:scale-95 text-white font-extrabold text-xs rounded-2xl shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all border border-indigo-400/30"
          >
            <Video className="w-4 h-4 text-amber-300" />
            <span>Watch Video for +5 Free Moves!</span>
          </button>

          {/* Use Inventory Extra Moves */}
          {hasExtraMovesInInventory && (
            <button
              onClick={() => {
                sound.click();
                onUseExtraMoves();
              }}
              className="w-full py-2.5 bg-emerald-600/30 hover:bg-emerald-600/40 text-emerald-300 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 border border-emerald-500/40 transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Use +5 Moves Booster</span>
            </button>
          )}
        </div>

        {/* Retry & Map Actions */}
        <div className="w-full flex gap-2.5">
          <button
            onClick={() => {
              sound.click();
              onRetry();
            }}
            className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 active:scale-95 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Retry</span>
          </button>

          <button
            onClick={() => {
              sound.click();
              onLevelSelect();
            }}
            className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-300 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all"
          >
            <Map className="w-4 h-4" />
            <span>Level Map</span>
          </button>
        </div>
      </div>
    </div>
  );
};
