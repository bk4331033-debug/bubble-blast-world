/**
 * Bubble Blast World - AdMob Rewarded & Interstitial Ad Simulator
 * Simulates mobile video advertisement with official AdMob compliance.
 */

import React, { useEffect, useState } from 'react';
import { X, Play, Award, Sparkles, ShieldCheck } from 'lucide-react';
import { AdType } from '../game/admob';
import { sound } from '../game/sound';

interface AdMobModalProps {
  type: AdType;
  isOpen: boolean;
  onRewardEarned: () => void;
  onClose: () => void;
}

export const AdMobModal: React.FC<AdMobModalProps> = ({
  type,
  isOpen,
  onRewardEarned,
  onClose,
}) => {
  const [secondsRemaining, setSecondsRemaining] = useState(5);
  const [rewardGranted, setRewardGranted] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      setSecondsRemaining(5);
      setRewardGranted(false);
      return;
    }

    const timer = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setRewardGranted(true);
          sound.win();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen]);

  if (!isOpen) return null;

  const handleClaimAndClose = () => {
    sound.click();
    if (rewardGranted) {
      onRewardEarned();
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 backdrop-blur-md">
      <div className="relative w-full max-w-sm overflow-hidden rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl flex flex-col">
        {/* AdMob Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-950/80 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="bg-amber-500/20 text-amber-400 text-[10px] font-bold px-2 py-0.5 rounded border border-amber-500/30">
              Ad · Google AdMob
            </span>
            <div className="flex items-center text-xs text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 mr-1" />
              <span>Verified Sponsor</span>
            </div>
          </div>

          {rewardGranted ? (
            <button
              onClick={handleClaimAndClose}
              className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-3 py-1 rounded-full transition-colors"
            >
              <X className="w-4 h-4" />
              <span>Claim</span>
            </button>
          ) : (
            <div className="flex items-center gap-1.5 text-xs text-slate-300 font-mono">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
              <span>Reward in {secondsRemaining}s</span>
            </div>
          )}
        </div>

        {/* Video Simulation Content */}
        <div className="relative p-6 flex flex-col items-center justify-center text-center bg-gradient-to-b from-indigo-950/70 via-slate-900 to-slate-950 min-h-[300px]">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-rose-500 via-amber-400 to-indigo-500 p-0.5 mb-4 shadow-lg shadow-indigo-500/20">
            <div className="w-full h-full bg-slate-900 rounded-[14px] flex items-center justify-center">
              <Sparkles className="w-10 h-10 text-amber-400 animate-bounce" />
            </div>
          </div>

          <h3 className="text-xl font-bold text-white mb-1">
            Super Bubble Blast Arena!
          </h3>
          <p className="text-xs text-slate-300 mb-6 max-w-xs">
            Unlock legendary power-ups, defeat daily challenges, and blast bubbles with players worldwide!
          </p>

          {/* Reward Status Banner */}
          {rewardGranted ? (
            <div className="w-full bg-emerald-500/20 border border-emerald-500/40 rounded-2xl p-3 flex items-center justify-center gap-2 text-emerald-300 font-bold text-sm animate-pulse">
              <Award className="w-5 h-5 text-emerald-400" />
              <span>
                {type === 'REWARDED_MOVES' ? '+5 Extra Moves Unlocked!' : '+150 Coins Awarded!'}
              </span>
            </div>
          ) : (
            <div className="w-full bg-slate-800/80 rounded-2xl p-3 flex items-center justify-between text-xs text-slate-400">
              <span>Watching sponsor clip...</span>
              <div className="w-24 bg-slate-700 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-amber-400 h-full transition-all duration-1000 ease-linear"
                  style={{ width: `${((5 - secondsRemaining) / 5) * 100}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* AdMob Footer CTA */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold text-white">Google Play Store</div>
            <div className="text-[11px] text-slate-400">Free Install · 4.9 ★★★★★</div>
          </div>

          <button
            onClick={handleClaimAndClose}
            disabled={!rewardGranted}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition-all ${
              rewardGranted
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-lg shadow-emerald-500/30 hover:scale-105 active:scale-95'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            {rewardGranted ? 'Collect & Continue' : `Wait ${secondsRemaining}s`}
          </button>
        </div>
      </div>
    </div>
  );
};
