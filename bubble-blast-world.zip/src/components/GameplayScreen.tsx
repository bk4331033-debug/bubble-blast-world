/**
 * Bubble Blast World - Core Gameplay Engine & Canvas Component
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Pause, RotateCw, Star, Trophy, Sparkles, Volume2, VolumeX } from 'lucide-react';
import {
  BubbleColor,
  FallingBubble,
  FloatingText,
  FlyingBubble,
  GridBubble,
  LevelConfig,
  Particle,
  PlayerStats,
  PowerUpInventory,
  SpecialBubbleType,
} from '../game/types';
import { getLevelConfig, ALL_COLORS } from '../game/levels';
import { sound } from '../game/sound';
import {
  COLOR_MAP,
  drawFloatingTexts,
  drawGlossyBubble,
  drawParticles,
  drawTrajectory,
} from '../game/canvasRenderer';
import { PowerUpBar } from './PowerUpBar';

interface GameplayScreenProps {
  levelNumber: number;
  stats: PlayerStats;
  onLevelComplete: (score: number, stars: number, remainingMoves: number) => void;
  onGameOver: (score: number, goalDescription: string) => void;
  onPause: () => void;
  onOpenShop: () => void;
  onUpdateStats: (newStats: PlayerStats) => void;
  extraMovesGranted: number;
}

export const GameplayScreen: React.FC<GameplayScreenProps> = ({
  levelNumber,
  stats,
  onLevelComplete,
  onGameOver,
  onPause,
  onOpenShop,
  onUpdateStats,
  extraMovesGranted,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Level configuration
  const [levelConfig, setLevelConfig] = useState<LevelConfig>(() => getLevelConfig(levelNumber));
  const [score, setScore] = useState(0);
  const [remainingMoves, setRemainingMoves] = useState(levelConfig.maxMoves);
  const [gemsRescued, setGemsRescued] = useState(0);
  const [comboCount, setComboCount] = useState(0);

  // Power-up state
  const [selectedPowerUp, setSelectedPowerUp] = useState<'RAINBOW' | 'BOMB' | 'FIRE' | null>(null);
  const [aimGuideActive, setAimGuideActive] = useState(false);

  // Grid dimensions
  const BUBBLE_RADIUS = 21.5;
  const ROW_HEIGHT = BUBBLE_RADIUS * Math.sqrt(3);

  // Mutable game state in ref for 60fps canvas loop
  const gameState = useRef<{
    width: number;
    height: number;
    grid: (GridBubble | null)[][];
    currentBubble: { color: BubbleColor; type: SpecialBubbleType };
    nextBubble: { color: BubbleColor; type: SpecialBubbleType };
    flyingBubble: FlyingBubble | null;
    fallingBubbles: FallingBubble[];
    particles: Particle[];
    floatingTexts: FloatingText[];
    aimAngle: number;
    isAiming: boolean;
    launcherX: number;
    launcherY: number;
    isGameOver: boolean;
    isWon: boolean;
  }>({
    width: 400,
    height: 600,
    grid: [],
    currentBubble: { color: 'RED', type: 'NORMAL' },
    nextBubble: { color: 'BLUE', type: 'NORMAL' },
    flyingBubble: null,
    fallingBubbles: [],
    particles: [],
    floatingTexts: [],
    aimAngle: -Math.PI / 2, // Aim straight up initially
    isAiming: false,
    launcherX: 200,
    launcherY: 535,
    isGameOver: false,
    isWon: false,
  });

  // Pick a random available color from the current level
  const getRandomColor = useCallback(
    (available: BubbleColor[]): BubbleColor => {
      // Prefer colors currently present in grid if possible
      const colorsInGrid = new Set<BubbleColor>();
      for (const row of gameState.current.grid) {
        for (const b of row) {
          if (b && b.type === 'NORMAL') colorsInGrid.add(b.color);
        }
      }
      const pool = colorsInGrid.size > 0 ? Array.from(colorsInGrid) : available;
      return pool[Math.floor(Math.random() * pool.length)] || available[0] || 'RED';
    },
    []
  );

  // Initialize level
  useEffect(() => {
    const cfg = getLevelConfig(levelNumber);
    setLevelConfig(cfg);
    setScore(0);
    setRemainingMoves(cfg.maxMoves);
    setGemsRescued(0);
    setComboCount(0);
    setSelectedPowerUp(null);
    setAimGuideActive(false);

    // Deep copy grid
    const initialGrid = cfg.rows.map((row) =>
      row.map((b) => (b ? { ...b } : null))
    );

    gameState.current.grid = initialGrid;
    gameState.current.currentBubble = {
      color: cfg.availableColors[Math.floor(Math.random() * cfg.availableColors.length)],
      type: 'NORMAL',
    };
    gameState.current.nextBubble = {
      color: cfg.availableColors[Math.floor(Math.random() * cfg.availableColors.length)],
      type: 'NORMAL',
    };
    gameState.current.flyingBubble = null;
    gameState.current.fallingBubbles = [];
    gameState.current.particles = [];
    gameState.current.floatingTexts = [];
    gameState.current.isGameOver = false;
    gameState.current.isWon = false;
  }, [levelNumber]);

  // Apply extra moves from rewarded ads or booster
  useEffect(() => {
    if (extraMovesGranted > 0) {
      setRemainingMoves((m) => m + extraMovesGranted);
      gameState.current.isGameOver = false;
    }
  }, [extraMovesGranted]);

  // Calculate pixel coordinates for a hex cell
  const getHexCoords = useCallback(
    (row: number, col: number, canvasWidth: number) => {
      const isOdd = row % 2 === 1;
      const cols = isOdd ? 7 : 8;
      const totalRowWidth = (cols - 1) * (BUBBLE_RADIUS * 2);
      const startX = (canvasWidth - totalRowWidth) / 2;

      const x = startX + col * (BUBBLE_RADIUS * 2);
      const y = BUBBLE_RADIUS + 8 + row * ROW_HEIGHT;
      return { x, y };
    },
    [BUBBLE_RADIUS, ROW_HEIGHT]
  );

  // Swap current and next bubble
  const handleSwapBubbles = () => {
    if (gameState.current.flyingBubble) return;
    sound.click();
    const temp = { ...gameState.current.currentBubble };
    gameState.current.currentBubble = { ...gameState.current.nextBubble };
    gameState.current.nextBubble = temp;
    setSelectedPowerUp(null);
  };

  // Select power-up
  const handleSelectPowerUp = (type: 'RAINBOW' | 'BOMB' | 'FIRE') => {
    if (gameState.current.flyingBubble) return;
    if (selectedPowerUp === type) {
      // Toggle off
      setSelectedPowerUp(null);
      gameState.current.currentBubble.type = 'NORMAL';
    } else {
      setSelectedPowerUp(type);
      gameState.current.currentBubble.type = type;
      sound.powerupActivate(type);
    }
  };

  // Activate Super Aim Guide
  const handleActivateAimGuide = () => {
    if (aimGuideActive || stats.powerUps.aimGuide <= 0) return;
    sound.powerupActivate('AIM');
    setAimGuideActive(true);
    const updatedStats: PlayerStats = {
      ...stats,
      powerUps: {
        ...stats.powerUps,
        aimGuide: stats.powerUps.aimGuide - 1,
      },
    };
    onUpdateStats(updatedStats);
  };

  // Use extra moves power-up
  const handleUseExtraMoves = () => {
    if (stats.powerUps.extraMoves <= 0) return;
    sound.powerupActivate('MOVES');
    setRemainingMoves((m) => m + 5);
    const updatedStats: PlayerStats = {
      ...stats,
      powerUps: {
        ...stats.powerUps,
        extraMoves: stats.powerUps.extraMoves - 1,
      },
    };
    onUpdateStats(updatedStats);
  };

  // Launch the bubble with high speed and crisp responsiveness
  const launchBubble = () => {
    if (gameState.current.flyingBubble || gameState.current.isGameOver || gameState.current.isWon) {
      return;
    }

    sound.shoot();

    // Fast, responsive bubble launch (28 px/frame)
    const speed = 28;
    const angle = gameState.current.aimAngle;
    const vx = Math.cos(angle) * speed;
    const vy = Math.sin(angle) * speed;

    gameState.current.flyingBubble = {
      x: gameState.current.launcherX,
      y: gameState.current.launcherY,
      vx,
      vy,
      color: gameState.current.currentBubble.color,
      type: gameState.current.currentBubble.type,
      radius: BUBBLE_RADIUS,
      active: true,
    };

    // If a power-up was consumed, decrement inventory
    if (selectedPowerUp) {
      const key = selectedPowerUp.toLowerCase() as keyof PowerUpInventory;
      const updatedStats: PlayerStats = {
        ...stats,
        powerUps: {
          ...stats.powerUps,
          [key]: Math.max(0, stats.powerUps[key] - 1),
        },
      };
      onUpdateStats(updatedStats);
      setSelectedPowerUp(null);
    }

    // Set next bubble
    gameState.current.currentBubble = { ...gameState.current.nextBubble };
    gameState.current.nextBubble = {
      color: getRandomColor(levelConfig.availableColors),
      type: 'NORMAL',
    };

    setRemainingMoves((m) => Math.max(0, m - 1));
  };

  // Pointer / Touch aiming handlers
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    // Unlock Web Audio for mobile browsers on first touch
    sound.unlockAudio();

    if (gameState.current.flyingBubble) return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const px = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const py = ((e.clientY - rect.top) / rect.height) * canvas.height;

    // Do not aim if tapped directly on swap button
    if (
      Math.hypot(px - (gameState.current.launcherX - 54), py - (gameState.current.launcherY - 5)) <
      BUBBLE_RADIUS * 1.5
    ) {
      handleSwapBubbles();
      return;
    }

    gameState.current.isAiming = true;
    updateAim(px, py);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!gameState.current.isAiming || gameState.current.flyingBubble) return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const px = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const py = ((e.clientY - rect.top) / rect.height) * canvas.height;
    updateAim(px, py);
  };

  const handlePointerUp = () => {
    if (gameState.current.isAiming && !gameState.current.flyingBubble) {
      gameState.current.isAiming = false;
      launchBubble();
    }
  };

  const updateAim = (px: number, py: number) => {
    const lx = gameState.current.launcherX;
    const ly = gameState.current.launcherY;
    let angle = Math.atan2(py - ly, px - lx);

    // Clamp angle so bubble cannot shoot horizontally or downwards
    // Safe upward cone: from -165 deg to -15 deg
    const minAngle = -Math.PI * 0.92;
    const maxAngle = -Math.PI * 0.08;

    if (angle > 0) {
      // In lower hemisphere, clamp to nearest side
      angle = px < lx ? minAngle : maxAngle;
    } else {
      angle = Math.max(minAngle, Math.min(maxAngle, angle));
    }

    gameState.current.aimAngle = angle;
  };

  // Find 6 hex neighbors for row, col
  const getNeighbors = (r: number, c: number, grid: (GridBubble | null)[][]) => {
    const isOdd = r % 2 === 1;
    const neighbors: { r: number; c: number }[] = [];

    const dirsEven = [
      { dr: -1, dc: -1 },
      { dr: -1, dc: 0 },
      { dr: 0, dc: -1 },
      { dr: 0, dc: 1 },
      { dr: 1, dc: -1 },
      { dr: 1, dc: 0 },
    ];

    const dirsOdd = [
      { dr: -1, dc: 0 },
      { dr: -1, dc: 1 },
      { dr: 0, dc: -1 },
      { dr: 0, dc: 1 },
      { dr: 1, dc: 0 },
      { dr: 1, dc: 1 },
    ];

    const dirs = isOdd ? dirsOdd : dirsEven;

    for (const d of dirs) {
      const nr = r + d.dr;
      const nc = c + d.dc;
      if (nr >= 0 && nr < grid.length) {
        const maxCols = nr % 2 === 1 ? 7 : 8;
        if (nc >= 0 && nc < maxCols) {
          neighbors.push({ r: nr, c: nc });
        }
      }
    }

    return neighbors;
  };

  // Collision ray check for trajectory drawing
  const checkTrajectoryCollision = (x: number, y: number) => {
    const grid = gameState.current.grid;
    const width = gameState.current.width;

    for (let r = 0; r < grid.length; r++) {
      for (let c = 0; c < grid[r].length; c++) {
        const b = grid[r][c];
        if (b) {
          const coords = getHexCoords(r, c, width);
          if (Math.hypot(x - coords.x, y - coords.y) <= BUBBLE_RADIUS * 1.85) {
            return true;
          }
        }
      }
    }
    return false;
  };

  // Floating disconnected bubbles BFS
  const processFloatingBubbles = (grid: (GridBubble | null)[][], canvasWidth: number) => {
    const supported = new Set<string>();
    const queue: { r: number; c: number }[] = [];

    // All bubbles in row 0 are anchored to the ceiling
    if (grid[0]) {
      for (let c = 0; c < grid[0].length; c++) {
        if (grid[0][c]) {
          supported.add(`0,${c}`);
          queue.push({ r: 0, c });
        }
      }
    }

    // BFS to find all supported bubbles
    while (queue.length > 0) {
      const curr = queue.shift()!;
      const neighbors = getNeighbors(curr.r, curr.c, grid);

      for (const n of neighbors) {
        const key = `${n.r},${n.c}`;
        if (!supported.has(key) && grid[n.r][n.c]) {
          supported.add(key);
          queue.push(n);
        }
      }
    }

    // Any bubble in the grid not in 'supported' is detached and drops!
    const dropped: GridBubble[] = [];
    for (let r = 0; r < grid.length; r++) {
      for (let c = 0; c < grid[r].length; c++) {
        const b = grid[r][c];
        if (b && !supported.has(`${r},${c}`)) {
          dropped.push(b);
          grid[r][c] = null;
        }
      }
    }

    if (dropped.length > 0) {
      sound.drop(dropped.length);
      const dropBonus = dropped.length * 150;
      setScore((s) => s + dropBonus);

      // Spawn floating falling physics bubbles with fast downward velocity
      for (const d of dropped) {
        const coords = getHexCoords(d.row, d.col, canvasWidth);
        gameState.current.fallingBubbles.push({
          id: `fall-${d.id}`,
          x: coords.x,
          y: coords.y,
          vx: (Math.random() - 0.5) * 5,
          vy: 2 + Math.random() * 3, // fast downward initial plunge
          color: d.color,
          type: d.type,
          radius: BUBBLE_RADIUS,
          alpha: 1,
          rotation: 0,
          vRot: (Math.random() - 0.5) * 0.3,
        });

        if (d.type === 'STAR_GEM') {
          sound.gem();
          setGemsRescued((g) => g + 1);
        }
      }

      // Add floating score text
      gameState.current.floatingTexts.push({
        id: `text-${Date.now()}`,
        x: canvasWidth / 2,
        y: 200,
        text: `DROP BONUS! +${dropBonus}`,
        color: '#facc15',
        alpha: 1,
        scale: 1.2,
      });
    }
  };

  // Explode particles helper
  const spawnExplosionParticles = (x: number, y: number, colorName: BubbleColor, count: number = 14) => {
    const palette = COLOR_MAP[colorName] || COLOR_MAP.RED;
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count + (Math.random() - 0.5);
      const speed = 2.5 + Math.random() * 4.5;
      gameState.current.particles.push({
        id: `p-${Date.now()}-${i}`,
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color: Math.random() > 0.3 ? palette.main : palette.light,
        size: 3 + Math.random() * 3,
        alpha: 1,
        life: 0,
        maxLife: 20 + Math.random() * 15,
        type: Math.random() > 0.5 ? 'sparkle' : 'circle',
      });
    }
  };

  // Main game animation loop
  useEffect(() => {
    let animationFrameId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Responsive Canvas Resizing
    const resizeCanvas = () => {
      if (!containerRef.current) return;
      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;
      canvas.width = width;
      canvas.height = height;
      gameState.current.width = width;
      gameState.current.height = height;
      gameState.current.launcherX = width / 2;
      gameState.current.launcherY = height - 58;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    const render = () => {
      const width = gameState.current.width;
      const height = gameState.current.height;
      const grid = gameState.current.grid;

      ctx.clearRect(0, 0, width, height);

      // 1. Draw subtle background ceiling bar & danger line
      ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.fillRect(0, 0, width, 8);

      // Danger bottom line (if bubbles reach this, game over)
      const dangerY = height - 120;
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.25)';
      ctx.lineWidth = 1;
      ctx.setLineDash([6, 6]);
      ctx.beginPath();
      ctx.moveTo(0, dangerY);
      ctx.lineTo(width, dangerY);
      ctx.stroke();
      ctx.setLineDash([]);

      // 2. Draw Grid Bubbles
      let lowestBubbleY = 0;
      let totalBubblesRemaining = 0;
      let totalGemsRemaining = 0;

      for (let r = 0; r < grid.length; r++) {
        for (let c = 0; c < grid[r].length; c++) {
          const bubble = grid[r][c];
          if (bubble) {
            totalBubblesRemaining++;
            if (bubble.type === 'STAR_GEM') totalGemsRemaining++;
            const coords = getHexCoords(r, c, width);
            drawGlossyBubble(ctx, coords.x, coords.y, BUBBLE_RADIUS, bubble.color, bubble.type);
            if (coords.y > lowestBubbleY) lowestBubbleY = coords.y;
          }
        }
      }

      // Check win condition
      if (!gameState.current.isWon && !gameState.current.isGameOver) {
        let hasWon = false;
        if (levelConfig.goalType === 'CLEAR_ALL' && totalBubblesRemaining === 0) {
          hasWon = true;
        } else if (levelConfig.goalType === 'RESCUE_GEMS' && totalGemsRemaining === 0) {
          hasWon = true;
        } else if (levelConfig.goalType === 'CLEAR_CEILING' && grid[0].every((b) => b === null)) {
          hasWon = true;
        }

        if (hasWon) {
          gameState.current.isWon = true;
          sound.win();
          const finalScore = score + remainingMoves * 50;
          let stars = 1;
          if (finalScore >= levelConfig.starScores[2]) stars = 3;
          else if (finalScore >= levelConfig.starScores[1]) stars = 2;

          setTimeout(() => {
            onLevelComplete(finalScore, stars, remainingMoves);
          }, 350);
        } else if (
          !gameState.current.flyingBubble &&
          remainingMoves <= 0 &&
          totalBubblesRemaining > 0
        ) {
          // Out of moves
          gameState.current.isGameOver = true;
          sound.lose();
          setTimeout(() => {
            const goalDesc =
              levelConfig.goalType === 'RESCUE_GEMS'
                ? `Rescue all ${levelConfig.targetGemsCount} gems`
                : levelConfig.goalType === 'CLEAR_CEILING'
                ? 'Clear the top ceiling row'
                : 'Clear all bubbles';
            onGameOver(score, goalDesc);
          }, 350);
        } else if (lowestBubbleY >= dangerY) {
          // Crossed danger line
          gameState.current.isGameOver = true;
          sound.lose();
          setTimeout(() => {
            onGameOver(score, 'Ceiling descended past danger line!');
          }, 350);
        }
      }

      // 3. Draw Trajectory Line if aiming
      if (gameState.current.isAiming && !gameState.current.flyingBubble) {
        drawTrajectory(
          ctx,
          gameState.current.launcherX,
          gameState.current.launcherY,
          gameState.current.aimAngle,
          width,
          BUBBLE_RADIUS,
          aimGuideActive ? 3 : 1,
          aimGuideActive,
          checkTrajectoryCollision
        );
      }

      // 4. Update & Draw Flying Bubble Physics (using 2 sub-steps for smooth high-speed collision without tunneling)
      const flying = gameState.current.flyingBubble;
      if (flying && flying.active) {
        const subSteps = 2;
        const stepVx = flying.vx / subSteps;
        const stepVy = flying.vy / subSteps;

        for (let step = 0; step < subSteps; step++) {
          if (!flying.active) break;
          flying.x += stepVx;
          flying.y += stepVy;

          // Side wall bounce
          if (flying.x <= BUBBLE_RADIUS) {
            flying.x = BUBBLE_RADIUS;
            flying.vx = -flying.vx;
            sound.click();
          } else if (flying.x >= width - BUBBLE_RADIUS) {
            flying.x = width - BUBBLE_RADIUS;
            flying.vx = -flying.vx;
            sound.click();
          }

          // Special: FIRE BUBBLE pierce mechanics
          if (flying.type === 'FIRE') {
            for (let r = 0; r < grid.length; r++) {
              for (let c = 0; c < grid[r].length; c++) {
                const b = grid[r][c];
                if (b) {
                  const coords = getHexCoords(r, c, width);
                  if (Math.hypot(flying.x - coords.x, flying.y - coords.y) <= BUBBLE_RADIUS * 1.8) {
                    grid[r][c] = null;
                    spawnExplosionParticles(coords.x, coords.y, b.color, 10);
                    setScore((s) => s + 100);
                    if (b.type === 'STAR_GEM') {
                      sound.gem();
                      setGemsRescued((g) => g + 1);
                    }
                  }
                }
              }
            }
          }

          // Collision detection with existing grid bubbles (optimized by scanning only adjacent rows)
          let collisionOccurred = false;
          let collisionRow = -1;
          let collisionCol = -1;

          if (flying.type !== 'FIRE') {
            const approxRow = Math.max(0, Math.round((flying.y - BUBBLE_RADIUS - 8) / ROW_HEIGHT));
            const minRow = Math.max(0, approxRow - 2);
            const maxRow = Math.min(grid.length - 1, approxRow + 2);

            for (let r = minRow; r <= maxRow; r++) {
              for (let c = 0; c < grid[r].length; c++) {
                const b = grid[r][c];
                if (b) {
                  const coords = getHexCoords(r, c, width);
                  if (Math.hypot(flying.x - coords.x, flying.y - coords.y) <= BUBBLE_RADIUS * 1.85) {
                    collisionOccurred = true;
                    collisionRow = r;
                    collisionCol = c;
                    break;
                  }
                }
              }
              if (collisionOccurred) break;
            }
          }

          // Ceiling collision
          const hitCeiling = flying.y <= BUBBLE_RADIUS + 8;

          if (hitCeiling || collisionOccurred) {
            flying.active = false;
            gameState.current.flyingBubble = null;

            // Special: BOMB BUBBLE detonation
            if (flying.type === 'BOMB') {
              sound.bomb();
              const targetX = flying.x;
              const targetY = flying.y;
              let bombPops = 0;

              for (let r = 0; r < grid.length; r++) {
                for (let c = 0; c < grid[r].length; c++) {
                  const b = grid[r][c];
                  if (b) {
                    const coords = getHexCoords(r, c, width);
                    if (Math.hypot(targetX - coords.x, targetY - coords.y) <= BUBBLE_RADIUS * 4) {
                      grid[r][c] = null;
                      spawnExplosionParticles(coords.x, coords.y, b.color, 12);
                      bombPops++;
                      if (b.type === 'STAR_GEM') {
                        sound.gem();
                        setGemsRescued((g) => g + 1);
                      }
                    }
                  }
                }
              }

              const bombScore = bombPops * 120;
              setScore((s) => s + bombScore);
              processFloatingBubbles(grid, width);
              break;
            }

            // Special: FIRE reached ceiling
            if (flying.type === 'FIRE') {
              sound.fire();
              processFloatingBubbles(grid, width);
              break;
            }

            // Normal or RAINBOW placement
            let bestR = 0;
            let bestC = 0;
            let minDist = Infinity;

            const maxRowSearch = Math.min(grid.length + 1, 14);

            for (let r = 0; r < maxRowSearch; r++) {
              if (!grid[r]) {
                grid[r] = [];
              }
              const isOdd = r % 2 === 1;
              const maxCols = isOdd ? 7 : 8;

              for (let c = 0; c < maxCols; c++) {
                if (!grid[r][c]) {
                  const coords = getHexCoords(r, c, width);
                  const dist = Math.hypot(flying.x - coords.x, flying.y - coords.y);
                  if (dist < minDist) {
                    minDist = dist;
                    bestR = r;
                    bestC = c;
                  }
                }
              }
            }

            // Determine color (if Rainbow, copy color of collided bubble)
            let finalColor = flying.color;
            if (flying.type === 'RAINBOW' && collisionRow >= 0 && grid[collisionRow]?.[collisionCol]) {
              finalColor = grid[collisionRow][collisionCol]!.color;
            }

            // Place into grid immediately
            grid[bestR][bestC] = {
              id: `bubble-${bestR}-${bestC}-${Date.now()}`,
              row: bestR,
              col: bestC,
              color: finalColor,
              type: 'NORMAL',
            };

            // Match-3 BFS flood fill
            const matched: { r: number; c: number }[] = [];
            const visited = new Set<string>();
            const queue = [{ r: bestR, c: bestC }];
            visited.add(`${bestR},${bestC}`);

            while (queue.length > 0) {
              const curr = queue.shift()!;
              matched.push(curr);

              const neighbors = getNeighbors(curr.r, curr.c, grid);
              for (const n of neighbors) {
                const key = `${n.r},${n.c}`;
                if (!visited.has(key)) {
                  visited.add(key);
                  const neighborBubble = grid[n.r][n.c];
                  if (
                    neighborBubble &&
                    neighborBubble.type === 'NORMAL' &&
                    neighborBubble.color === finalColor
                  ) {
                    queue.push(n);
                  }
                }
              }
            }

            // Check if 3 or more matching bubbles connected
            if (matched.length >= 3 || flying.type === 'RAINBOW') {
              const newCombo = comboCount + 1;
              setComboCount(newCombo);
              // Trigger satisfying pop sound (small vs large group)
              sound.matchPop(matched.length, newCombo);

              let popCount = 0;
              for (const m of matched) {
                const coords = getHexCoords(m.r, m.c, width);
                grid[m.r][m.c] = null;
                spawnExplosionParticles(coords.x, coords.y, finalColor, 10);
                popCount++;

                // Check adjacent ice bubbles to melt
                const adjacent = getNeighbors(m.r, m.c, grid);
                for (const a of adjacent) {
                  const adjBubble = grid[a.r][a.c];
                  if (adjBubble && adjBubble.type === 'ICE') {
                    adjBubble.type = 'NORMAL';
                    spawnExplosionParticles(coords.x, coords.y, adjBubble.color, 8);
                  }
                }
              }

              const popScore = popCount * 100 * newCombo;
              setScore((s) => s + popScore);

              // Floating score text
              const firstCoord = getHexCoords(matched[0].r, matched[0].c, width);
              gameState.current.floatingTexts.push({
                id: `combo-${Date.now()}`,
                x: firstCoord.x,
                y: firstCoord.y - 15,
                text: newCombo > 1 ? `COMBO x${newCombo}! +${popScore}` : `+${popScore}`,
                color: '#38bdf8',
                alpha: 1,
                scale: newCombo > 1 ? 1.25 : 1,
              });

              // Process dropped/floating bubbles immediately
              processFloatingBubbles(grid, width);
            } else {
              // Bubble landed without forming a match
              setComboCount(0);
              sound.stick();
            }
            break;
          }
        }

        // Draw currently flying bubble
        if (flying.active) {
          drawGlossyBubble(ctx, flying.x, flying.y, flying.radius, flying.color, flying.type);
        }
      }

      // 5. Update & Draw Falling Physics Bubbles (faster descent)
      const falling = gameState.current.fallingBubbles;
      for (let i = falling.length - 1; i >= 0; i--) {
        const fb = falling[i];
        fb.x += fb.vx;
        fb.y += fb.vy;
        fb.vy += 1.25; // accelerated crisp gravity
        fb.rotation += fb.vRot;
        fb.alpha -= 0.035; // clean fast fade out

        drawGlossyBubble(ctx, fb.x, fb.y, fb.radius, fb.color, fb.type, fb.alpha, fb.rotation);

        if (fb.y > height + 50 || fb.alpha <= 0) {
          falling.splice(i, 1);
        }
      }

      // 6. Update & Draw Particles
      const particles = gameState.current.particles;
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.vx *= 0.96;
        p.vy *= 0.96;
        p.life++;
        p.alpha = 1 - p.life / p.maxLife;

        if (p.life >= p.maxLife) {
          particles.splice(i, 1);
        }
      }
      drawParticles(ctx, particles);

      // 7. Update & Draw Floating Texts
      const texts = gameState.current.floatingTexts;
      for (let i = texts.length - 1; i >= 0; i--) {
        const t = texts[i];
        t.y -= 1.2;
        t.alpha -= 0.02;
        if (t.alpha <= 0) {
          texts.splice(i, 1);
        }
      }
      drawFloatingTexts(ctx, texts);

      // 8. Draw Launcher Pedestal, Secondary Bubble & Current Ready Bubble
      const lx = gameState.current.launcherX;
      const ly = gameState.current.launcherY;

      // Pedestal ring
      ctx.save();
      ctx.beginPath();
      ctx.arc(lx, ly, BUBBLE_RADIUS * 1.5, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(15, 23, 42, 0.75)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Aim directional arrow pointer
      const arrowLength = BUBBLE_RADIUS * 1.8;
      const ax = lx + Math.cos(gameState.current.aimAngle) * arrowLength;
      const ay = ly + Math.sin(gameState.current.aimAngle) * arrowLength;
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(lx, ly);
      ctx.lineTo(ax, ay);
      ctx.stroke();
      ctx.restore();

      // Ready primary bubble in launcher
      const current = gameState.current.currentBubble;
      drawGlossyBubble(ctx, lx, ly, BUBBLE_RADIUS, current.color, current.type);

      // Secondary swap bubble holster
      const sx = lx - 54;
      const sy = ly - 5;
      const next = gameState.current.nextBubble;

      ctx.save();
      ctx.beginPath();
      ctx.arc(sx, sy, BUBBLE_RADIUS * 0.9, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(15, 23, 42, 0.7)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.restore();

      drawGlossyBubble(ctx, sx, sy, BUBBLE_RADIUS * 0.75, next.color, next.type);

      // Small swap arrow icon overlay on secondary
      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.font = '10px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('⇄', sx, sy + BUBBLE_RADIUS);

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', resizeCanvas);
    };
  }, [
    levelConfig,
    remainingMoves,
    score,
    aimGuideActive,
    BUBBLE_RADIUS,
    ROW_HEIGHT,
    comboCount,
    getHexCoords,
    onLevelComplete,
    onGameOver,
  ]);

  return (
    <div className="relative flex flex-col h-full w-full select-none overflow-hidden justify-between">
      {/* HUD Top Bar */}
      <div className="flex items-center justify-between px-3 py-2 bg-slate-950/80 backdrop-blur-md border-b border-slate-800 z-10">
        {/* Controls: Pause & Quick Sound Toggle */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => {
              sound.click();
              onPause();
            }}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 active:scale-95 text-slate-300 transition-all shadow-md"
            title="Pause"
          >
            <Pause className="w-5 h-5" />
          </button>

          <button
            onClick={() => {
              sound.click();
              const nextSound = !stats.soundEnabled;
              sound.updateSettings(nextSound, stats.musicEnabled, stats.soundVolume, stats.musicVolume);
              onUpdateStats({ ...stats, soundEnabled: nextSound });
            }}
            className={`p-2 rounded-xl border transition-all active:scale-95 shadow-md ${
              stats.soundEnabled
                ? 'bg-slate-900 border-emerald-500/40 text-emerald-400 hover:bg-slate-800'
                : 'bg-slate-900 border-slate-800 text-slate-500 hover:bg-slate-800'
            }`}
            title={stats.soundEnabled ? 'Mute Sound' : 'Enable Sound'}
          >
            {stats.soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
          </button>
        </div>

        {/* Goal Indicator Capsule */}
        <div className="flex items-center gap-2 px-3.5 py-1.5 bg-slate-900/90 border border-indigo-500/30 rounded-2xl shadow-md">
          <span className="text-sm">
            {levelConfig.goalType === 'RESCUE_GEMS' ? '💎' : '🎯'}
          </span>
          <div className="text-left">
            <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider leading-none">
              Level {levelNumber} Goal
            </div>
            <div className="text-xs font-bold text-white font-bubble">
              {levelConfig.goalType === 'RESCUE_GEMS'
                ? `Rescue Gems: ${gemsRescued}/${levelConfig.targetGemsCount}`
                : levelConfig.goalType === 'CLEAR_CEILING'
                ? 'Clear Top Ceiling Row'
                : 'Clear All Bubbles'}
            </div>
          </div>
        </div>

        {/* Moves Left Capsule */}
        <div className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 border border-amber-500/30 rounded-2xl shadow-md">
          <div className="text-right">
            <div className="text-[9px] text-slate-400 uppercase tracking-wider font-bold leading-none">
              Moves
            </div>
            <div
              className={`text-base font-extrabold font-mono leading-none ${
                remainingMoves <= 5 ? 'text-rose-400 animate-pulse' : 'text-amber-400'
              }`}
            >
              {remainingMoves}
            </div>
          </div>
        </div>
      </div>

      {/* Score and Combo Ribbon */}
      <div className="flex items-center justify-between px-4 py-1 bg-slate-950/50 text-xs text-slate-300 border-b border-slate-900/80 z-10">
        <div className="flex items-center gap-1">
          <span className="text-slate-400">Score:</span>
          <span className="font-bold text-amber-300 font-mono text-sm">{score.toLocaleString()}</span>
        </div>

        {comboCount > 1 && (
          <div className="flex items-center gap-1 text-sky-400 font-bold animate-bounce font-bubble">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Combo {comboCount}x!</span>
          </div>
        )}

        <div className="flex items-center gap-1 text-slate-400 text-[11px]">
          <span>World:</span>
          <span className="text-slate-200 font-semibold">{levelConfig.worldName}</span>
        </div>
      </div>

      {/* Main Interactive Canvas Area */}
      <div ref={containerRef} className="relative flex-1 w-full h-full overflow-hidden">
        <canvas
          ref={canvasRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          className="w-full h-full cursor-crosshair touch-none"
        />
      </div>

      {/* Power-up Hotbar & Swap Hint */}
      <div className="px-3 pb-3 pt-1 z-10">
        <PowerUpBar
          inventory={stats.powerUps}
          selectedPowerUp={selectedPowerUp}
          aimGuideActive={aimGuideActive}
          onSelectPowerUp={handleSelectPowerUp}
          onActivateAimGuide={handleActivateAimGuide}
          onUseExtraMoves={handleUseExtraMoves}
          onOpenShop={onOpenShop}
        />
      </div>
    </div>
  );
};
