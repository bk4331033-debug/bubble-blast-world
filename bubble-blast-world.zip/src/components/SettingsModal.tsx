/**
 * Bubble Blast World - Settings & Info Modal
 */

import React, { useState } from 'react';
import { X, Volume2, VolumeX, Music, Smartphone, HelpCircle, Trash2, SmartphoneNfc, Info, ShieldCheck } from 'lucide-react';
import { PlayerStats } from '../game/types';
import { sound } from '../game/sound';

interface SettingsModalProps {
  stats: PlayerStats;
  isOpen: boolean;
  onClose: () => void;
  onUpdateStats: (newStats: PlayerStats) => void;
  onOpenAndroidExport: () => void;
  onResetProgress: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  stats,
  isOpen,
  onClose,
  onUpdateStats,
  onOpenAndroidExport,
  onResetProgress,
}) => {
  const [showHowToPlay, setShowHowToPlay] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  if (!isOpen) return null;

  const currentSoundVol = stats.soundVolume ?? 0.8;
  const currentMusicVol = stats.musicVolume ?? 0.5;

  const toggleSound = () => {
    sound.click();
    const nextVal = !stats.soundEnabled;
    sound.updateSettings(nextVal, stats.musicEnabled, currentSoundVol, currentMusicVol);
    onUpdateStats({ ...stats, soundEnabled: nextVal });
  };

  const toggleMusic = () => {
    sound.click();
    const nextVal = !stats.musicEnabled;
    sound.updateSettings(stats.soundEnabled, nextVal, currentSoundVol, currentMusicVol);
    onUpdateStats({ ...stats, musicEnabled: nextVal });
  };

  const handleSoundVolumeChange = (vol: number) => {
    sound.setVolume(vol, currentMusicVol);
    onUpdateStats({ ...stats, soundVolume: vol });
  };

  const handleMusicVolumeChange = (vol: number) => {
    sound.setVolume(currentSoundVol, vol);
    onUpdateStats({ ...stats, musicVolume: vol });
  };

  const toggleHaptic = () => {
    sound.click();
    onUpdateStats({ ...stats, hapticEnabled: !stats.hapticEnabled });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="relative w-full max-w-md max-h-[90vh] overflow-hidden rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-slate-950/90 border-b border-slate-800">
          <h2 className="text-xl font-bold text-white font-bubble">Settings</h2>

          <button
            onClick={() => {
              sound.click();
              onClose();
            }}
            className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Audio Controls */}
          <div className="space-y-2.5">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Audio & Controls</span>

            {/* Sound FX Card */}
            <div className="p-3.5 bg-slate-800/60 rounded-2xl border border-slate-700/60 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {stats.soundEnabled ? <Volume2 className="w-5 h-5 text-emerald-400" /> : <VolumeX className="w-5 h-5 text-slate-500" />}
                  <div>
                    <div className="text-sm font-bold text-white">Sound Effects</div>
                    <div className="text-xs text-slate-400">Bubble pops, chimes, and explosions</div>
                  </div>
                </div>
                <button
                  onClick={toggleSound}
                  className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${
                    stats.soundEnabled ? 'bg-emerald-600 text-white shadow-md' : 'bg-slate-800 text-slate-500'
                  }`}
                >
                  {stats.soundEnabled ? 'ON' : 'OFF'}
                </button>
              </div>

              {stats.soundEnabled && (
                <div className="flex items-center gap-3 pt-1 border-t border-slate-700/40">
                  <span className="text-[11px] text-slate-400 w-12 font-medium">Volume</span>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={currentSoundVol}
                    onChange={(e) => handleSoundVolumeChange(parseFloat(e.target.value))}
                    className="w-full accent-emerald-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
                  />
                  <span className="text-xs font-mono text-slate-300 w-8 text-right">
                    {Math.round(currentSoundVol * 100)}%
                  </span>
                </div>
              )}
            </div>

            {/* Music Card */}
            <div className="p-3.5 bg-slate-800/60 rounded-2xl border border-slate-700/60 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Music className={`w-5 h-5 ${stats.musicEnabled ? 'text-indigo-400' : 'text-slate-500'}`} />
                  <div>
                    <div className="text-sm font-bold text-white">Arcade Synth Music</div>
                    <div className="text-xs text-slate-400">Ambient background rhythm</div>
                  </div>
                </div>
                <button
                  onClick={toggleMusic}
                  className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${
                    stats.musicEnabled ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-800 text-slate-500'
                  }`}
                >
                  {stats.musicEnabled ? 'ON' : 'OFF'}
                </button>
              </div>

              {stats.musicEnabled && (
                <div className="flex items-center gap-3 pt-1 border-t border-slate-700/40">
                  <span className="text-[11px] text-slate-400 w-12 font-medium">Volume</span>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={currentMusicVol}
                    onChange={(e) => handleMusicVolumeChange(parseFloat(e.target.value))}
                    className="w-full accent-indigo-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
                  />
                  <span className="text-xs font-mono text-slate-300 w-8 text-right">
                    {Math.round(currentMusicVol * 100)}%
                  </span>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between p-3.5 bg-slate-800/60 rounded-2xl border border-slate-700/60">
              <div className="flex items-center gap-3">
                <Smartphone className={`w-5 h-5 ${stats.hapticEnabled ? 'text-amber-400' : 'text-slate-500'}`} />
                <div>
                  <div className="text-sm font-bold text-white">Haptic Vibration</div>
                  <div className="text-xs text-slate-400">Tactile impact response</div>
                </div>
              </div>
              <button
                onClick={toggleHaptic}
                className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${
                  stats.hapticEnabled ? 'bg-amber-600 text-white shadow-md' : 'bg-slate-800 text-slate-500'
                }`}
              >
                {stats.hapticEnabled ? 'ON' : 'OFF'}
              </button>
            </div>
          </div>

          {/* How to Play Guide Accordion */}
          <div className="space-y-2">
            <button
              onClick={() => {
                sound.click();
                setShowHowToPlay(!showHowToPlay);
              }}
              className="w-full flex items-center justify-between p-3.5 bg-slate-800/60 hover:bg-slate-800 rounded-2xl border border-slate-700/60 transition-all text-left"
            >
              <div className="flex items-center gap-3">
                <HelpCircle className="w-5 h-5 text-sky-400" />
                <span className="text-sm font-bold text-white">How To Play</span>
              </div>
              <span className="text-xs text-slate-400">{showHowToPlay ? 'Hide' : 'View Guide'}</span>
            </button>

            {showHowToPlay && (
              <div className="p-4 bg-slate-950/70 rounded-2xl border border-slate-800 text-xs text-slate-300 space-y-2 leading-relaxed">
                <p>🎯 <strong className="text-white">Aim & Shoot:</strong> Touch or drag on the screen to aim your bubble launcher. Release to shoot!</p>
                <p>🫧 <strong className="text-white">Match 3+:</strong> Connect 3 or more bubbles of the same color to blast them away.</p>
                <p>💫 <strong className="text-white">Drop Bonus:</strong> Any bubbles cut off from the ceiling drop down for bonus points and coins!</p>
                <p>🔄 <strong className="text-white">Swap Bubbles:</strong> Tap the secondary bubble near your launcher to swap with the next color.</p>
                <p>💣 <strong className="text-white">Power-ups:</strong> Use Bombs, Fire Piercers, Rainbow spheres, and Super Aim from your hotbar to clear tough formations!</p>
              </div>
            )}
          </div>

          {/* Android APK & AdMob Integration Info */}
          <button
            onClick={() => {
              sound.click();
              onOpenAndroidExport();
            }}
            className="w-full flex items-center justify-between p-3.5 bg-gradient-to-r from-emerald-950/60 to-slate-800 hover:bg-slate-800 rounded-2xl border border-emerald-500/30 transition-all text-left"
          >
            <div className="flex items-center gap-3">
              <SmartphoneNfc className="w-5 h-5 text-emerald-400" />
              <div>
                <div className="text-sm font-bold text-white">Android Build & Google Play</div>
                <div className="text-[11px] text-emerald-300">APK, AAB, AdMob & Store Publishing Instructions</div>
              </div>
            </div>
            <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded-lg border border-emerald-500/20">
              Guide
            </span>
          </button>

          {/* About & Copyright */}
          <div className="p-4 bg-slate-950/50 rounded-2xl border border-slate-800 text-center text-xs text-slate-400 space-y-1">
            <div className="flex items-center justify-center gap-1.5 text-white font-bold mb-1">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Bubble Blast World v1.0</span>
            </div>
            <p>100% Original Artwork, Code & Audio Synthesizer.</p>
            <p className="text-[11px] text-slate-500">Offline Ready · Google Play Compliant</p>
          </div>

          {/* Danger Zone: Reset */}
          <div className="pt-2">
            {confirmReset ? (
              <div className="p-3 bg-red-950/40 border border-red-500/40 rounded-2xl text-center space-y-2">
                <p className="text-xs text-red-300 font-bold">Are you sure? All progress and coins will be reset!</p>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      sound.lose();
                      onResetProgress();
                      setConfirmReset(false);
                      onClose();
                    }}
                    className="flex-1 py-1.5 bg-red-600 hover:bg-red-500 text-white text-xs font-bold rounded-xl"
                  >
                    Confirm Reset
                  </button>
                  <button
                    onClick={() => setConfirmReset(false)}
                    className="flex-1 py-1.5 bg-slate-800 text-slate-300 text-xs font-bold rounded-xl"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setConfirmReset(true)}
                className="w-full py-2.5 text-xs text-rose-400 hover:text-rose-300 flex items-center justify-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                <span>Reset Game Progress</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
