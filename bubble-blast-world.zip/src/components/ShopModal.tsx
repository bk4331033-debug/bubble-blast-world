/**
 * Bubble Blast World - Shop & Monetization Modal
 * Power-ups, Coin Bundles, AdMob Video Rewards, and Google Play IAP simulation
 */

import React, { useState } from 'react';
import { X, Coins, Sparkles, Video, Check, ShoppingBag, ShieldCheck } from 'lucide-react';
import { PlayerStats, PowerUpInventory } from '../game/types';
import { sound } from '../game/sound';

interface ShopModalProps {
  stats: PlayerStats;
  isOpen: boolean;
  onClose: () => void;
  onUpdateStats: (newStats: PlayerStats) => void;
  onWatchAd: () => void;
}

export const ShopModal: React.FC<ShopModalProps> = ({
  stats,
  isOpen,
  onClose,
  onUpdateStats,
  onWatchAd,
}) => {
  const [activeTab, setActiveTab] = useState<'POWERUPS' | 'COINS' | 'IAP'>('POWERUPS');
  const [purchaseSuccessMessage, setPurchaseSuccessMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const showSuccess = (msg: string) => {
    sound.win();
    setPurchaseSuccessMessage(msg);
    setTimeout(() => setPurchaseSuccessMessage(null), 2500);
  };

  const buyWithCoins = (cost: number, applyReward: (inv: PowerUpInventory) => PowerUpInventory, label: string) => {
    sound.click();
    if (stats.coins < cost) {
      sound.lose();
      setPurchaseSuccessMessage('Not enough coins! Watch an ad or clear levels!');
      setTimeout(() => setPurchaseSuccessMessage(null), 2500);
      return;
    }

    const updatedInv = applyReward({ ...stats.powerUps });
    const updatedStats: PlayerStats = {
      ...stats,
      coins: stats.coins - cost,
      powerUps: updatedInv,
    };
    onUpdateStats(updatedStats);
    showSuccess(`Purchased ${label}!`);
  };

  // Google Play simulated IAP purchase
  const simulateIAP = (coinsToAdd: number, priceStr: string) => {
    sound.click();
    const updatedStats: PlayerStats = {
      ...stats,
      coins: stats.coins + coinsToAdd,
    };
    onUpdateStats(updatedStats);
    showSuccess(`Purchased ${coinsToAdd.toLocaleString()} Coins for ${priceStr}!`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="relative w-full max-w-md max-h-[90vh] overflow-hidden rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-slate-950/90 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-6 h-6 text-amber-400" />
            <h2 className="text-xl font-bold text-white font-bubble">Blast Shop</h2>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-500/20 border border-amber-500/30 rounded-full">
              <Coins className="w-4 h-4 text-amber-400" />
              <span className="text-sm font-bold text-amber-300 font-mono">
                {stats.coins.toLocaleString()}
              </span>
            </div>

            <button
              onClick={() => {
                sound.click();
                onClose();
              }}
              className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="flex p-2 bg-slate-950/60 border-b border-slate-800/80 gap-1">
          <button
            onClick={() => {
              sound.click();
              setActiveTab('POWERUPS');
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
              activeTab === 'POWERUPS'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            Power-Ups
          </button>
          <button
            onClick={() => {
              sound.click();
              setActiveTab('COINS');
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
              activeTab === 'COINS'
                ? 'bg-amber-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            Free Rewards
          </button>
          <button
            onClick={() => {
              sound.click();
              setActiveTab('IAP');
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
              activeTab === 'IAP'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            Google Play Store
          </button>
        </div>

        {/* Success / Alert Banner */}
        {purchaseSuccessMessage && (
          <div className="bg-emerald-500/20 border-b border-emerald-500/30 px-4 py-2 text-center text-xs font-bold text-emerald-300 flex items-center justify-center gap-1.5 animate-pulse">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>{purchaseSuccessMessage}</span>
          </div>
        )}

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {/* TAB 1: POWERUPS */}
          {activeTab === 'POWERUPS' && (
            <div className="space-y-3">
              {/* Bomb Pack */}
              <div className="flex items-center justify-between p-3.5 bg-slate-800/60 hover:bg-slate-800 rounded-2xl border border-slate-700/60 transition-all">
                <div className="flex items-center gap-3">
                  <div className="text-3xl p-2 bg-red-500/20 rounded-xl border border-red-500/30">💣</div>
                  <div>
                    <div className="font-bold text-sm text-white">Bomb Pack (x3)</div>
                    <div className="text-xs text-slate-400">Blows up a huge 2-hex area</div>
                  </div>
                </div>
                <button
                  onClick={() =>
                    buyWithCoins(200, (inv) => ({ ...inv, bomb: inv.bomb + 3 }), '3x Bomb')
                  }
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1 shadow-md transition-all"
                >
                  <Coins className="w-3.5 h-3.5" />
                  <span>200</span>
                </button>
              </div>

              {/* Fire Pack */}
              <div className="flex items-center justify-between p-3.5 bg-slate-800/60 hover:bg-slate-800 rounded-2xl border border-slate-700/60 transition-all">
                <div className="flex items-center gap-3">
                  <div className="text-3xl p-2 bg-orange-500/20 rounded-xl border border-orange-500/30">🔥</div>
                  <div>
                    <div className="font-bold text-sm text-white">Fire Blast (x3)</div>
                    <div className="text-xs text-slate-400">Pierces bubbles in trajectory line</div>
                  </div>
                </div>
                <button
                  onClick={() =>
                    buyWithCoins(200, (inv) => ({ ...inv, fire: inv.fire + 3 }), '3x Fire')
                  }
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1 shadow-md transition-all"
                >
                  <Coins className="w-3.5 h-3.5" />
                  <span>200</span>
                </button>
              </div>

              {/* Rainbow Pack */}
              <div className="flex items-center justify-between p-3.5 bg-slate-800/60 hover:bg-slate-800 rounded-2xl border border-slate-700/60 transition-all">
                <div className="flex items-center gap-3">
                  <div className="text-3xl p-2 bg-purple-500/20 rounded-xl border border-purple-500/30">🌈</div>
                  <div>
                    <div className="font-bold text-sm text-white">Rainbow Sphere (x3)</div>
                    <div className="text-xs text-slate-400">Matches any colored bubble cluster</div>
                  </div>
                </div>
                <button
                  onClick={() =>
                    buyWithCoins(250, (inv) => ({ ...inv, rainbow: inv.rainbow + 3 }), '3x Rainbow')
                  }
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1 shadow-md transition-all"
                >
                  <Coins className="w-3.5 h-3.5" />
                  <span>250</span>
                </button>
              </div>

              {/* Aim Guide Pack */}
              <div className="flex items-center justify-between p-3.5 bg-slate-800/60 hover:bg-slate-800 rounded-2xl border border-slate-700/60 transition-all">
                <div className="flex items-center gap-3">
                  <div className="text-3xl p-2 bg-sky-500/20 rounded-xl border border-sky-500/30">🎯</div>
                  <div>
                    <div className="font-bold text-sm text-white">Super Aim Guide (x5)</div>
                    <div className="text-xs text-slate-400">Multi-bounce long laser targeting</div>
                  </div>
                </div>
                <button
                  onClick={() =>
                    buyWithCoins(150, (inv) => ({ ...inv, aimGuide: inv.aimGuide + 5 }), '5x Aim')
                  }
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1 shadow-md transition-all"
                >
                  <Coins className="w-3.5 h-3.5" />
                  <span>150</span>
                </button>
              </div>

              {/* Extra Moves Pack */}
              <div className="flex items-center justify-between p-3.5 bg-slate-800/60 hover:bg-slate-800 rounded-2xl border border-slate-700/60 transition-all">
                <div className="flex items-center gap-3">
                  <div className="text-3xl p-2 bg-emerald-500/20 rounded-xl border border-emerald-500/30">➕</div>
                  <div>
                    <div className="font-bold text-sm text-white">+5 Extra Moves (x3)</div>
                    <div className="text-xs text-slate-400">Save yourself from game over!</div>
                  </div>
                </div>
                <button
                  onClick={() =>
                    buyWithCoins(200, (inv) => ({ ...inv, extraMoves: inv.extraMoves + 3 }), '3x Extra Moves')
                  }
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1 shadow-md transition-all"
                >
                  <Coins className="w-3.5 h-3.5" />
                  <span>200</span>
                </button>
              </div>

              {/* Mega Bundle */}
              <div className="p-4 bg-gradient-to-r from-purple-900/50 to-indigo-900/50 rounded-2xl border border-purple-500/40 relative overflow-hidden">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-purple-300 bg-purple-500/20 px-2 py-0.5 rounded">
                    BEST VALUE BUNDLE
                  </span>
                  <Sparkles className="w-4 h-4 text-amber-300" />
                </div>
                <div className="text-base font-bold text-white mb-1">Mega Blaster Crate</div>
                <div className="text-xs text-slate-300 mb-3">
                  Includes 2x Bomb, 2x Fire, 2x Rainbow, 3x Aim, 2x Extra Moves!
                </div>
                <button
                  onClick={() =>
                    buyWithCoins(
                      650,
                      (inv) => ({
                        rainbow: inv.rainbow + 2,
                        bomb: inv.bomb + 2,
                        fire: inv.fire + 2,
                        aimGuide: inv.aimGuide + 3,
                        extraMoves: inv.extraMoves + 2,
                      }),
                      'Mega Blaster Crate'
                    )
                  }
                  className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 active:scale-95 text-slate-950 font-extrabold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-lg transition-all"
                >
                  <Coins className="w-4 h-4" />
                  <span>Unlock for 650 Coins</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: FREE REWARDS & ADMOB */}
          {activeTab === 'COINS' && (
            <div className="space-y-3">
              {/* AdMob Rewarded Video */}
              <div className="p-4 bg-gradient-to-r from-indigo-950/70 to-blue-950/70 rounded-2xl border border-indigo-500/30">
                <div className="flex items-center gap-3 mb-3">
                  <div className="p-3 bg-indigo-500/20 rounded-xl text-indigo-400">
                    <Video className="w-7 h-7" />
                  </div>
                  <div>
                    <div className="font-bold text-white text-sm">Watch Sponsored Video</div>
                    <div className="text-xs text-indigo-200">Earn +150 Coins for free via Google AdMob</div>
                  </div>
                </div>
                <button
                  onClick={() => {
                    sound.click();
                    onWatchAd();
                  }}
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-md transition-all"
                >
                  <Video className="w-4 h-4" />
                  <span>Watch Video Ad (+150 Coins)</span>
                </button>
              </div>

              {/* Free Daily Stash */}
              <div className="p-4 bg-slate-800/60 rounded-2xl border border-slate-700/60">
                <div className="flex items-center justify-between mb-2">
                  <div className="font-bold text-white text-sm">Daily Blaster Gift</div>
                  <span className="text-xs text-emerald-400 font-bold">Free Daily</span>
                </div>
                <p className="text-xs text-slate-400 mb-3">
                  Claim bonus power-ups and coins every 24 hours on the Daily Rewards calendar!
                </p>
                <div className="text-xs text-slate-300 bg-slate-900/60 p-2.5 rounded-xl border border-white/5">
                  Check out the Daily Calendar from the main menu for continuous 7-day bonus streaks.
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: GOOGLE PLAY BILLING IAP */}
          {activeTab === 'IAP' && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-950/50 p-2.5 rounded-xl border border-slate-800">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Google Play In-App Billing Compliance Ready</span>
              </div>

              {/* Tier 1 */}
              <div className="flex items-center justify-between p-3.5 bg-slate-800/60 hover:bg-slate-800 rounded-2xl border border-slate-700/60 transition-all">
                <div className="flex items-center gap-3">
                  <div className="text-2xl p-2 bg-amber-500/20 rounded-xl">💰</div>
                  <div>
                    <div className="font-bold text-sm text-white">Starter Coin Pouch</div>
                    <div className="text-xs text-amber-400 font-bold">+1,000 Coins</div>
                  </div>
                </div>
                <button
                  onClick={() => simulateIAP(1000, '$0.99')}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md transition-all"
                >
                  $0.99
                </button>
              </div>

              {/* Tier 2 */}
              <div className="flex items-center justify-between p-3.5 bg-slate-800/60 hover:bg-slate-800 rounded-2xl border border-slate-700/60 transition-all">
                <div className="flex items-center gap-3">
                  <div className="text-2xl p-2 bg-amber-500/20 rounded-xl">💎</div>
                  <div>
                    <div className="font-bold text-sm text-white">Blaster Treasure Chest</div>
                    <div className="text-xs text-amber-400 font-bold">+3,500 Coins (Popular)</div>
                  </div>
                </div>
                <button
                  onClick={() => simulateIAP(3500, '$2.99')}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md transition-all"
                >
                  $2.99
                </button>
              </div>

              {/* Tier 3 */}
              <div className="flex items-center justify-between p-3.5 bg-slate-800/60 hover:bg-slate-800 rounded-2xl border border-slate-700/60 transition-all">
                <div className="flex items-center gap-3">
                  <div className="text-2xl p-2 bg-amber-500/20 rounded-xl">👑</div>
                  <div>
                    <div className="font-bold text-sm text-white">Cosmic Vault of Gold</div>
                    <div className="text-xs text-amber-400 font-bold">+10,000 Coins (Best Value)</div>
                  </div>
                </div>
                <button
                  onClick={() => simulateIAP(10000, '$4.99')}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md transition-all"
                >
                  $4.99
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
