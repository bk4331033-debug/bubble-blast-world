/**
 * Bubble Blast World - Power-Up Action Bar
 */

import React from 'react';
import { PowerUpInventory } from '../game/types';
import { sound } from '../game/sound';

interface PowerUpBarProps {
  inventory: PowerUpInventory;
  selectedPowerUp: 'RAINBOW' | 'BOMB' | 'FIRE' | null;
  aimGuideActive: boolean;
  onSelectPowerUp: (type: 'RAINBOW' | 'BOMB' | 'FIRE') => void;
  onActivateAimGuide: () => void;
  onUseExtraMoves: () => void;
  onOpenShop: () => void;
}

export const PowerUpBar: React.FC<PowerUpBarProps> = ({
  inventory,
  selectedPowerUp,
  aimGuideActive,
  onSelectPowerUp,
  onActivateAimGuide,
  onUseExtraMoves,
  onOpenShop,
}) => {
  const handlePowerUpClick = (type: 'RAINBOW' | 'BOMB' | 'FIRE') => {
    sound.click();
    if (inventory[type.toLowerCase() as keyof PowerUpInventory] > 0) {
      onSelectPowerUp(type);
    } else {
      onOpenShop();
    }
  };

  const handleAimClick = () => {
    sound.click();
    if (inventory.aimGuide > 0 && !aimGuideActive) {
      onActivateAimGuide();
    } else if (inventory.aimGuide <= 0) {
      onOpenShop();
    }
  };

  const handleMovesClick = () => {
    sound.click();
    if (inventory.extraMoves > 0) {
      onUseExtraMoves();
    } else {
      onOpenShop();
    }
  };

  return (
    <div className="flex items-center justify-around w-full px-3 py-2 bg-slate-900/90 backdrop-blur-md rounded-2xl border border-white/10 shadow-lg">
      {/* 1. Bomb */}
      <button
        onClick={() => handlePowerUpClick('BOMB')}
        className={`relative flex flex-col items-center justify-center p-2 rounded-xl transition-all ${
          selectedPowerUp === 'BOMB'
            ? 'bg-red-500/30 border-2 border-red-400 scale-105 shadow-md shadow-red-500/30'
            : 'hover:bg-slate-800/80 active:scale-95'
        }`}
        title="Bomb: Explodes 2-hex radius"
      >
        <span className="text-2xl filter drop-shadow">💣</span>
        <span className="text-[10px] font-bold text-slate-300 mt-0.5">Bomb</span>
        <span className="absolute -top-1.5 -right-1.5 bg-amber-500 text-slate-950 font-extrabold text-[10px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-slate-900">
          {inventory.bomb}
        </span>
      </button>

      {/* 2. Fire */}
      <button
        onClick={() => handlePowerUpClick('FIRE')}
        className={`relative flex flex-col items-center justify-center p-2 rounded-xl transition-all ${
          selectedPowerUp === 'FIRE'
            ? 'bg-orange-500/30 border-2 border-orange-400 scale-105 shadow-md shadow-orange-500/30'
            : 'hover:bg-slate-800/80 active:scale-95'
        }`}
        title="Fire: Pierces straight through bubbles"
      >
        <span className="text-2xl filter drop-shadow">🔥</span>
        <span className="text-[10px] font-bold text-slate-300 mt-0.5">Fire</span>
        <span className="absolute -top-1.5 -right-1.5 bg-amber-500 text-slate-950 font-extrabold text-[10px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-slate-900">
          {inventory.fire}
        </span>
      </button>

      {/* 3. Rainbow */}
      <button
        onClick={() => handlePowerUpClick('RAINBOW')}
        className={`relative flex flex-col items-center justify-center p-2 rounded-xl transition-all ${
          selectedPowerUp === 'RAINBOW'
            ? 'bg-purple-500/30 border-2 border-purple-400 scale-105 shadow-md shadow-purple-500/30'
            : 'hover:bg-slate-800/80 active:scale-95'
        }`}
        title="Rainbow: Matches any color bubble"
      >
        <span className="text-2xl filter drop-shadow">🌈</span>
        <span className="text-[10px] font-bold text-slate-300 mt-0.5">Rainbow</span>
        <span className="absolute -top-1.5 -right-1.5 bg-amber-500 text-slate-950 font-extrabold text-[10px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-slate-900">
          {inventory.rainbow}
        </span>
      </button>

      {/* 4. Aim Guide */}
      <button
        onClick={handleAimClick}
        disabled={aimGuideActive}
        className={`relative flex flex-col items-center justify-center p-2 rounded-xl transition-all ${
          aimGuideActive
            ? 'bg-sky-500/30 border-2 border-sky-400 scale-105'
            : 'hover:bg-slate-800/80 active:scale-95'
        }`}
        title="Super Aim: Extended multi-bounce laser"
      >
        <span className="text-2xl filter drop-shadow">🎯</span>
        <span className="text-[10px] font-bold text-slate-300 mt-0.5">Aim</span>
        <span className="absolute -top-1.5 -right-1.5 bg-amber-500 text-slate-950 font-extrabold text-[10px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-slate-900">
          {inventory.aimGuide}
        </span>
      </button>

      {/* 5. Extra Moves */}
      <button
        onClick={handleMovesClick}
        className="relative flex flex-col items-center justify-center p-2 rounded-xl hover:bg-slate-800/80 active:scale-95 transition-all"
        title="Extra Moves: +5 Shooting Bubbles"
      >
        <span className="text-2xl filter drop-shadow">➕</span>
        <span className="text-[10px] font-bold text-slate-300 mt-0.5">+5 Moves</span>
        <span className="absolute -top-1.5 -right-1.5 bg-amber-500 text-slate-950 font-extrabold text-[10px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-slate-900">
          {inventory.extraMoves}
        </span>
      </button>
    </div>
  );
};
