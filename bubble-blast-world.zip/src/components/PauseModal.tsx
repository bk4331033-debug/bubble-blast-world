/**
 * Bubble Blast World - In-Game Pause Menu
 */

import React from 'react';
import { Play, RotateCcw, Map, Volume2, VolumeX, Music, Smartphone } from 'lucide-react';
import { sound } from '../game/sound';

interface PauseModalProps {
  levelNumber: number;
  isOpen: boolean;
  soundEnabled: boolean;
  musicEnabled: boolean;
  soundVolume?: number;
  musicVolume?: number;
  hapticEnabled: boolean;
  onResume: () => void;
  onRestart: () => void;
  onLevelSelect: () => void;
  onToggleSound: () => void;
  onToggleMusic: () => void;
  onChangeSoundVolume?: (vol: number) => void;
  onChangeMusicVolume?: (vol: number) => void;
  onToggleHaptic: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  levelNumber,
  isOpen,
  soundEnabled,
  musicEnabled,
  soundVolume = 0.8,
  musicVolume = 0.5,
  hapticEnabled,
  onResume,
  onRestart,
  onLevelSelect,
  onToggleSound,
  onToggleMusic,
  onChangeSoundVolume,
  onChangeMusicVolume,
  onToggleHaptic,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md">
      <div className="relative w-full max-w-sm overflow-hidden rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl flex flex-col items-center p-6 text-center">
        <h2 className="text-2xl font-extrabold text-white font-bubble mb-1">Game Paused</h2>
        <span className="text-xs text-slate-400 mb-6">Level {levelNumber}</span>

        {/* Settings Toggles & Volume Sliders */}
        <div className="w-full bg-slate-950/70 rounded-2xl p-3.5 border border-slate-800 space-y-3 mb-6">
          {/* Sound FX Toggle & Slider */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span className="flex items-center gap-2">
                {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
                <span className="font-semibold">Sound Effects</span>
              </span>
              <button
                onClick={() => {
                  sound.click();
                  onToggleSound();
                }}
                className={`px-3 py-1 rounded-full text-xs font-bold transition-colors ${
                  soundEnabled ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-500'
                }`}
              >
                {soundEnabled ? 'ON' : 'OFF'}
              </button>
            </div>
            {soundEnabled && onChangeSoundVolume && (
              <div className="flex items-center gap-2 px-1 pt-1">
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={soundVolume}
                  onChange={(e) => onChangeSoundVolume(parseFloat(e.target.value))}
                  className="w-full accent-emerald-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                />
                <span className="text-[10px] font-mono text-slate-400 w-7 text-right">
                  {Math.round(soundVolume * 100)}%
                </span>
              </div>
            )}
          </div>

          {/* Music Toggle & Slider */}
          <div className="space-y-1.5 border-t border-slate-800/80 pt-2.5">
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span className="flex items-center gap-2">
                <Music className={`w-4 h-4 ${musicEnabled ? 'text-indigo-400' : 'text-slate-500'}`} />
                <span className="font-semibold">Background Music</span>
              </span>
              <button
                onClick={() => {
                  sound.click();
                  onToggleMusic();
                }}
                className={`px-3 py-1 rounded-full text-xs font-bold transition-colors ${
                  musicEnabled ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-500'
                }`}
              >
                {musicEnabled ? 'ON' : 'OFF'}
              </button>
            </div>
            {musicEnabled && onChangeMusicVolume && (
              <div className="flex items-center gap-2 px-1 pt-1">
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={musicVolume}
                  onChange={(e) => onChangeMusicVolume(parseFloat(e.target.value))}
                  className="w-full accent-indigo-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                />
                <span className="text-[10px] font-mono text-slate-400 w-7 text-right">
                  {Math.round(musicVolume * 100)}%
                </span>
              </div>
            )}
          </div>

          {/* Vibration / Haptics Toggle */}
          <div className="border-t border-slate-800/80 pt-2.5 flex items-center justify-between text-xs text-slate-300">
            <span className="flex items-center gap-2">
              <Smartphone className={`w-4 h-4 ${hapticEnabled ? 'text-amber-400' : 'text-slate-500'}`} />
              <span className="font-semibold">Vibration / Haptics</span>
            </span>
            <button
              onClick={() => {
                sound.click();
                onToggleHaptic();
              }}
              className={`px-3 py-1 rounded-full text-xs font-bold transition-colors ${
                hapticEnabled ? 'bg-amber-600 text-white' : 'bg-slate-800 text-slate-500'
              }`}
            >
              {hapticEnabled ? 'ON' : 'OFF'}
            </button>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="w-full space-y-2.5">
          <button
            onClick={() => {
              sound.click();
              onResume();
            }}
            className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 active:scale-95 text-white font-extrabold text-sm rounded-2xl shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 transition-all"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Resume Game</span>
          </button>

          <button
            onClick={() => {
              sound.click();
              onRestart();
            }}
            className="w-full py-3 bg-slate-800 hover:bg-slate-700 active:scale-95 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-all"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Restart Level</span>
          </button>

          <button
            onClick={() => {
              sound.click();
              onLevelSelect();
            }}
            className="w-full py-3 bg-slate-800/80 hover:bg-slate-700 active:scale-95 text-slate-300 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-all"
          >
            <Map className="w-4 h-4" />
            <span>Quit to Level Map</span>
          </button>
        </div>
      </div>
    </div>
  );
};
