/**
 * Bubble Blast World - 7-Day Daily Rewards Calendar
 */

import React from 'react';
import { X, Calendar, Check, Gift, Sparkles } from 'lucide-react';
import { DAILY_REWARDS_TABLE } from '../game/storage';
import { PlayerStats, PowerUpInventory } from '../game/types';
import { sound } from '../game/sound';

interface DailyRewardsModalProps {
  stats: PlayerStats;
  isOpen: boolean;
  onClose: () => void;
  onUpdateStats: (newStats: PlayerStats) => void;
}

export const DailyRewardsModal: React.FC<DailyRewardsModalProps> = ({
  stats,
  isOpen,
  onClose,
  onUpdateStats,
}) => {
  if (!isOpen) return null;

  const now = Date.now();
  const ONE_DAY_MS = 24 * 60 * 60 * 1000;
  const timeSinceLastClaim = now - stats.lastDailyClaimTimestamp;
  const canClaimToday = stats.lastDailyClaimTimestamp === 0 || timeSinceLastClaim >= ONE_DAY_MS;

  // Next reward day is based on claimed days count (1..7, then loops or resets)
  const currentClaimDayIndex = (stats.claimedDailyDays.length % 7) + 1;

  const handleClaim = () => {
    if (!canClaimToday) return;

    sound.win();
    const rewardItem = DAILY_REWARDS_TABLE[currentClaimDayIndex - 1];

    let newCoins = stats.coins;
    let newPowerUps: PowerUpInventory = { ...stats.powerUps };

    if (rewardItem.type === 'COINS') {
      newCoins += rewardItem.amount;
    } else if (rewardItem.type === 'AIM_GUIDE') {
      newPowerUps.aimGuide += rewardItem.amount;
    } else if (rewardItem.type === 'BOMB') {
      newPowerUps.bomb += rewardItem.amount;
    } else if (rewardItem.type === 'FIRE') {
      newPowerUps.fire += rewardItem.amount;
    } else if (rewardItem.type === 'RAINBOW') {
      newPowerUps.rainbow += rewardItem.amount;
    } else if (rewardItem.type === 'JACKPOT') {
      newCoins += 500;
      newPowerUps.bomb += 2;
      newPowerUps.fire += 2;
      newPowerUps.rainbow += 2;
      newPowerUps.aimGuide += 2;
      newPowerUps.extraMoves += 2;
    }

    const updatedClaimed = [...stats.claimedDailyDays, currentClaimDayIndex];

    const updatedStats: PlayerStats = {
      ...stats,
      coins: newCoins,
      powerUps: newPowerUps,
      claimedDailyDays: updatedClaimed,
      lastDailyClaimTimestamp: now,
    };

    onUpdateStats(updatedStats);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="relative w-full max-w-md overflow-hidden rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-slate-950/90 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Calendar className="w-6 h-6 text-emerald-400" />
            <h2 className="text-xl font-bold text-white font-bubble">Daily Rewards</h2>
          </div>

          <button
            onClick={() => {
              sound.click();
              onClose();
            }}
            className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Calendar Grid */}
        <div className="p-4 space-y-4">
          <p className="text-xs text-slate-300 text-center">
            Log in daily to claim coins, power-ups, and the Day 7 Grand Jackpot!
          </p>

          <div className="grid grid-cols-4 gap-2.5">
            {DAILY_REWARDS_TABLE.slice(0, 6).map((item) => {
              const isClaimed = stats.claimedDailyDays.includes(item.day);
              const isReady = canClaimToday && item.day === currentClaimDayIndex;

              return (
                <div
                  key={item.day}
                  className={`relative flex flex-col items-center p-3 rounded-2xl border text-center transition-all ${
                    isClaimed
                      ? 'bg-slate-950/70 border-emerald-500/40 text-slate-400 opacity-80'
                      : isReady
                      ? 'bg-gradient-to-b from-emerald-950/60 to-slate-800 border-emerald-400 shadow-lg shadow-emerald-500/20 scale-105'
                      : 'bg-slate-800/60 border-slate-700/60 text-slate-300'
                  }`}
                >
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                    Day {item.day}
                  </span>
                  <span className="text-2xl mb-1">{item.icon}</span>
                  <span className="text-[10px] font-bold line-clamp-1">{item.label}</span>

                  {isClaimed && (
                    <div className="absolute inset-0 bg-slate-950/70 rounded-2xl flex items-center justify-center backdrop-blur-[1px]">
                      <Check className="w-6 h-6 text-emerald-400" />
                    </div>
                  )}
                </div>
              );
            })}

            {/* Day 7 Grand Reward spanning 2 columns */}
            {(() => {
              const item = DAILY_REWARDS_TABLE[6];
              const isClaimed = stats.claimedDailyDays.includes(item.day);
              const isReady = canClaimToday && item.day === currentClaimDayIndex;

              return (
                <div
                  className={`col-span-2 relative flex items-center justify-between p-3.5 rounded-2xl border transition-all ${
                    isClaimed
                      ? 'bg-slate-950/70 border-emerald-500/40 text-slate-400 opacity-80'
                      : isReady
                      ? 'bg-gradient-to-r from-amber-950/70 to-purple-950/70 border-amber-400 shadow-lg shadow-amber-500/20 scale-102'
                      : 'bg-gradient-to-r from-purple-950/50 to-slate-800 border-purple-500/40'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">👑</span>
                    <div className="text-left">
                      <div className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">
                        Day 7 Grand Jackpot
                      </div>
                      <div className="text-xs font-bold text-white">500 Coins + 2 All Power-ups</div>
                    </div>
                  </div>

                  {isClaimed && (
                    <div className="absolute inset-0 bg-slate-950/70 rounded-2xl flex items-center justify-center backdrop-blur-[1px]">
                      <Check className="w-6 h-6 text-emerald-400" />
                    </div>
                  )}
                </div>
              );
            })()}
          </div>

          {/* Action CTA */}
          <div className="pt-2">
            {canClaimToday ? (
              <button
                onClick={handleClaim}
                className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 active:scale-95 text-white font-extrabold text-sm rounded-2xl shadow-xl shadow-emerald-500/30 flex items-center justify-center gap-2 transition-all"
              >
                <Gift className="w-5 h-5" />
                <span>Claim Day {currentClaimDayIndex} Reward!</span>
              </button>
            ) : (
              <div className="w-full py-3 bg-slate-800 text-slate-400 text-xs font-semibold rounded-2xl text-center border border-slate-700/60">
                Next reward unlocks tomorrow! Keep playing!
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
