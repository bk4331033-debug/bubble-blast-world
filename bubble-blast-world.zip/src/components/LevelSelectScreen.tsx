/**
 * Bubble Blast World - 500 Level Selection Screen
 * Multi-World pagination with star tracking and lock status
 */

import React, { useState, useEffect } from 'react';
import { ArrowLeft, Star, Lock, Coins, Sparkles, ChevronLeft, ChevronRight } from 'lucide-react';
import { WORLDS } from '../game/levels';
import { PlayerStats } from '../game/types';
import { sound } from '../game/sound';

interface LevelSelectScreenProps {
  stats: PlayerStats;
  onSelectLevel: (lvl: number) => void;
  onBackToMenu: () => void;
  onOpenShop: () => void;
}

export const LevelSelectScreen: React.FC<LevelSelectScreenProps> = ({
  stats,
  onSelectLevel,
  onBackToMenu,
  onOpenShop,
}) => {
  // Find player's current world
  const currentLevelWorld = WORLDS.find(
    (w) => stats.unlockedLevel >= w.minLevel && stats.unlockedLevel <= w.maxLevel
  ) || WORLDS[0];

  const [activeWorldIndex, setActiveWorldIndex] = useState(currentLevelWorld.index);

  const activeWorld = WORLDS[activeWorldIndex - 1] || WORLDS[0];

  const totalStars = Object.values(stats.levelStars).reduce((acc, curr) => acc + curr, 0);

  // Generate levels for current world
  const levelsInCurrentWorld = Array.from(
    { length: activeWorld.maxLevel - activeWorld.minLevel + 1 },
    (_, i) => activeWorld.minLevel + i
  );

  return (
    <div className="relative flex flex-col h-full w-full bg-slate-950 text-white select-none overflow-hidden">
      {/* Top Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-900/90 border-b border-slate-800 z-10">
        <button
          onClick={() => {
            sound.click();
            onBackToMenu();
          }}
          className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 active:scale-95 transition-all text-slate-200"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-500/10 border border-amber-500/20 rounded-full">
            <Star className="w-4 h-4 fill-amber-400 text-amber-300" />
            <span className="text-xs font-bold text-amber-300 font-mono">{totalStars}</span>
          </div>

          <button
            onClick={() => {
              sound.click();
              onOpenShop();
            }}
            className="flex items-center gap-1.5 px-3 py-1 bg-amber-500/20 border border-amber-500/30 rounded-full hover:bg-amber-500/30 transition-all active:scale-95"
          >
            <Coins className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold text-amber-300 font-mono">
              {stats.coins.toLocaleString()}
            </span>
          </button>
        </div>
      </div>

      {/* World Navigator Header */}
      <div className="px-4 py-2 bg-slate-900/60 border-b border-slate-800 flex items-center justify-between">
        <button
          onClick={() => {
            sound.click();
            if (activeWorldIndex > 1) setActiveWorldIndex((w) => w - 1);
          }}
          disabled={activeWorldIndex <= 1}
          className="p-1.5 rounded-lg bg-slate-800 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-slate-700 active:scale-95 text-slate-300"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <div className="text-center">
          <div className="flex items-center justify-center gap-1.5 text-sm font-bold text-white font-bubble">
            <span>{activeWorld.icon}</span>
            <span>World {activeWorld.index}: {activeWorld.name}</span>
          </div>
          <span className="text-[11px] text-slate-400">
            Levels {activeWorld.minLevel} - {activeWorld.maxLevel} (500 Levels Total)
          </span>
        </div>

        <button
          onClick={() => {
            sound.click();
            if (activeWorldIndex < WORLDS.length) setActiveWorldIndex((w) => w + 1);
          }}
          disabled={activeWorldIndex >= WORLDS.length}
          className="p-1.5 rounded-lg bg-slate-800 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-slate-700 active:scale-95 text-slate-300"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* World Pills Scrollbar */}
      <div className="flex gap-2 px-4 py-2 overflow-x-auto bg-slate-950/80 border-b border-slate-800/80 no-scrollbar">
        {WORLDS.map((w) => {
          const isCurrentActive = w.index === activeWorldIndex;
          const isUnlocked = stats.unlockedLevel >= w.minLevel;

          return (
            <button
              key={w.index}
              onClick={() => {
                sound.click();
                setActiveWorldIndex(w.index);
              }}
              className={`flex items-center gap-1 px-3 py-1 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                isCurrentActive
                  ? 'bg-gradient-to-r from-indigo-600 to-blue-600 text-white shadow-md'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>{w.icon}</span>
              <span>W{w.index}</span>
              {!isUnlocked && <Lock className="w-3 h-3 text-slate-500 ml-0.5" />}
            </button>
          );
        })}
      </div>

      {/* Level Buttons Grid (50 levels per world) */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="grid grid-cols-5 gap-3 max-w-md mx-auto pb-8">
          {levelsInCurrentWorld.map((lvl) => {
            const isUnlocked = lvl <= stats.unlockedLevel;
            const stars = stats.levelStars[lvl] || 0;
            const isCurrentTarget = lvl === stats.unlockedLevel;

            return (
              <button
                key={lvl}
                disabled={!isUnlocked}
                onClick={() => {
                  sound.click();
                  onSelectLevel(lvl);
                }}
                className={`relative aspect-square rounded-2xl flex flex-col items-center justify-center p-1.5 transition-all ${
                  isUnlocked
                    ? isCurrentTarget
                      ? 'bg-gradient-to-br from-amber-500 to-orange-500 text-slate-950 shadow-lg shadow-amber-500/40 ring-4 ring-amber-400/50 scale-105 active:scale-95 font-black'
                      : 'bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700/80 text-white hover:border-indigo-400 hover:scale-105 active:scale-95 font-bold shadow-md'
                    : 'bg-slate-950/60 border border-slate-900 text-slate-600 cursor-not-allowed'
                }`}
              >
                {isUnlocked ? (
                  <>
                    <span className="text-base font-bubble">{lvl}</span>
                    <div className="flex gap-0.5 mt-0.5">
                      {[1, 2, 3].map((s) => (
                        <Star
                          key={s}
                          className={`w-2.5 h-2.5 ${
                            s <= stars
                              ? isCurrentTarget
                                ? 'fill-slate-950 text-slate-950'
                                : 'fill-amber-400 text-amber-300'
                              : 'text-slate-600 fill-slate-800'
                          }`}
                        />
                      ))}
                    </div>
                  </>
                ) : (
                  <Lock className="w-5 h-5 text-slate-600" />
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
