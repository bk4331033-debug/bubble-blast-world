/**
 * Bubble Blast World - Level Complete Modal
 */

import React from 'react';
import { Star, Play, RotateCcw, Map, Coins } from 'lucide-react';
import { sound } from '../game/sound';

interface LevelCompleteModalProps {
  levelNumber: number;
  score: number;
  starsEarned: number;
  coinsEarned: number;
  remainingMoves: number;
  isOpen: boolean;
  onNextLevel: () => void;
  onReplay: () => void;
  onLevelSelect: () => void;
}

export const LevelCompleteModal: React.FC<LevelCompleteModalProps> = ({
  levelNumber,
  score,
  starsEarned,
  coinsEarned,
  remainingMoves,
  isOpen,
  onNextLevel,
  onReplay,
  onLevelSelect,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md">
      <div className="relative w-full max-w-sm overflow-hidden rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl flex flex-col items-center p-6 text-center animate-in fade-in zoom-in-95 duration-200">
        {/* Glow backdrop */}
        <div className="absolute -top-16 left-1/2 -translate-x-1/2 w-48 h-48 bg-amber-500/20 blur-3xl rounded-full pointer-events-none" />

        <span className="text-xs font-bold tracking-widest text-amber-400 uppercase mb-1">
          Level {levelNumber} Cleared!
        </span>
        <h2 className="text-3xl font-extrabold text-white font-bubble mb-4">
          Victory!
        </h2>

        {/* 3 Stars Awarded */}
        <div className="flex items-center justify-center gap-3 mb-6">
          {[1, 2, 3].map((starIdx) => {
            const hasStar = starIdx <= starsEarned;
            return (
              <div
                key={starIdx}
                className={`transition-all duration-500 transform ${
                  hasStar ? 'scale-110 drop-shadow-[0_0_12px_rgba(250,204,21,0.6)]' : 'opacity-30 scale-90'
                }`}
              >
                <Star
                  className={`w-12 h-12 ${
                    hasStar
                      ? 'fill-amber-400 text-amber-300'
                      : 'fill-slate-700 text-slate-600'
                  }`}
                />
              </div>
            );
          })}
        </div>

        {/* Score & Rewards Box */}
        <div className="w-full bg-slate-950/70 rounded-2xl p-4 border border-slate-800 space-y-2 mb-6">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Level Score</span>
            <span className="text-sm font-bold text-white font-mono">{score.toLocaleString()}</span>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Moves Remaining Bonus</span>
            <span className="text-xs font-semibold text-emerald-400 font-mono">
              +{remainingMoves * 50} pts ({remainingMoves} moves)
            </span>
          </div>

          <div className="border-t border-slate-800 pt-2 flex items-center justify-between text-xs text-slate-300">
            <span className="flex items-center gap-1.5 font-bold">
              <Coins className="w-4 h-4 text-amber-400" />
              <span>Coins Earned</span>
            </span>
            <span className="text-sm font-extrabold text-amber-400 font-mono">
              +{coinsEarned}
            </span>
          </div>
        </div>

        {/* Buttons */}
        <div className="w-full space-y-2.5">
          <button
            onClick={() => {
              sound.click();
              onNextLevel();
            }}
            className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 active:scale-95 text-white font-extrabold text-base rounded-2xl shadow-xl shadow-emerald-500/25 flex items-center justify-center gap-2 transition-all"
          >
            <Play className="w-5 h-5 fill-current" />
            <span>Next Level</span>
          </button>

          <div className="flex gap-2.5">
            <button
              onClick={() => {
                sound.click();
                onReplay();
              }}
              className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-300 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Replay</span>
            </button>

            <button
              onClick={() => {
                sound.click();
                onLevelSelect();
              }}
              className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-300 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all"
            >
              <Map className="w-4 h-4" />
              <span>Level Map</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
