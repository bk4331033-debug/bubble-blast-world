/**
 * Bubble Blast World - Android Build & Google Play Store Publishing Guide
 * Complete, release-ready APK/AAB configuration and publishing checklist.
 */

import React, { useState } from 'react';
import { X, Smartphone, Copy, Check, Terminal, ShieldAlert, Award } from 'lucide-react';
import { sound } from '../game/sound';

interface AndroidExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidExportModal: React.FC<AndroidExportModalProps> = ({ isOpen, onClose }) => {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, id: string) => {
    sound.click();
    navigator.clipboard.writeText(text);
    setCopiedSection(id);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const capacitorConfig = `{
  "appId": "com.bubbleblast.world",
  "appName": "Bubble Blast World",
  "webDir": "dist",
  "bundledWebRuntime": false,
  "plugins": {
    "AdMob": {
      "appId": "ca-app-pub-3940256099942544~3347511713"
    }
  }
}`;

  const manifestSnippet = `<!-- Add to android/app/src/main/AndroidManifest.xml inside <application> -->
<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="ca-app-pub-3940256099942544~3347511713"/>
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.VIBRATE"/>`;

  const buildCommands = `# 1. Install Capacitor dependencies
npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor-community/admob

# 2. Build the production web bundle
npm run build

# 3. Initialize and sync Android project
npx cap init "Bubble Blast World" com.bubbleblast.world --web-dir dist
npx cap add android
npx cap sync android

# 4. Open in Android Studio & Generate Signed Bundle (AAB)
npx cap open android
# In Android Studio: Build -> Generate Signed Bundle / APK -> Android App Bundle (.aab)`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-md">
      <div className="relative w-full max-w-xl max-h-[90vh] overflow-hidden rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-slate-950/90 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Smartphone className="w-6 h-6 text-emerald-400" />
            <h2 className="text-xl font-bold text-white font-bubble">Android Release & Publishing</h2>
          </div>

          <button
            onClick={() => {
              sound.click();
              onClose();
            }}
            className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5 text-xs text-slate-300">
          {/* Overview */}
          <div className="p-3.5 bg-emerald-950/30 rounded-2xl border border-emerald-500/30 text-emerald-200 leading-relaxed">
            <strong>Bubble Blast World</strong> is architected as a high-performance, touch-first mobile game with 60 FPS Canvas rendering, Web Audio synthesis, and zero external network bottlenecks. It can be built directly into an Android APK or release AAB for Google Play Store using Capacitor.
          </div>

          {/* Section 1: Build Commands */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white uppercase text-[11px] tracking-wider flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-sky-400" />
                <span>1. Generate Android Project & Build AAB</span>
              </span>
              <button
                onClick={() => copyToClipboard(buildCommands, 'build')}
                className="flex items-center gap-1 text-[11px] text-sky-400 hover:text-sky-300 font-semibold"
              >
                {copiedSection === 'build' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSection === 'build' ? 'Copied!' : 'Copy Commands'}</span>
              </button>
            </div>
            <pre className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] text-slate-200 overflow-x-auto">
              {buildCommands}
            </pre>
          </div>

          {/* Section 2: capacitor.config.json */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white uppercase text-[11px] tracking-wider">
                2. Capacitor Configuration (capacitor.config.json)
              </span>
              <button
                onClick={() => copyToClipboard(capacitorConfig, 'cap')}
                className="flex items-center gap-1 text-[11px] text-sky-400 hover:text-sky-300 font-semibold"
              >
                {copiedSection === 'cap' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSection === 'cap' ? 'Copied!' : 'Copy JSON'}</span>
              </button>
            </div>
            <pre className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] text-amber-300 overflow-x-auto">
              {capacitorConfig}
            </pre>
          </div>

          {/* Section 3: AndroidManifest.xml */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white uppercase text-[11px] tracking-wider">
                3. Google AdMob AndroidManifest.xml Entry
              </span>
              <button
                onClick={() => copyToClipboard(manifestSnippet, 'manifest')}
                className="flex items-center gap-1 text-[11px] text-sky-400 hover:text-sky-300 font-semibold"
              >
                {copiedSection === 'manifest' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSection === 'manifest' ? 'Copied!' : 'Copy XML'}</span>
              </button>
            </div>
            <pre className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] text-emerald-300 overflow-x-auto">
              {manifestSnippet}
            </pre>
          </div>

          {/* Section 4: Google Play Store Publishing Checklist */}
          <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800 space-y-2.5">
            <div className="font-bold text-white text-xs flex items-center gap-1.5">
              <Award className="w-4 h-4 text-amber-400" />
              <span>Google Play Console Submission Checklist</span>
            </div>
            <ul className="space-y-1.5 text-[11px] text-slate-300 list-disc list-inside">
              <li><strong>App Category:</strong> Games / Casual / Puzzle</li>
              <li><strong>Content Rating:</strong> Everyone (PEGI 3 / ESRB E)</li>
              <li><strong>Target Android SDK:</strong> Android 14+ (API 34)</li>
              <li><strong>Target Architecture:</strong> Universal 64-bit (arm64-v8a, x86_64)</li>
              <li><strong>Icons & Banners:</strong> App Icon (512x512 PNG), Feature Graphic (1024x500 PNG)</li>
              <li><strong>Screenshots:</strong> Minimum 4 phone screenshots (1080x1920 or 9:16)</li>
              <li><strong>Data Safety:</strong> Compliant with offline play; declared AdMob SDK data practices</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
