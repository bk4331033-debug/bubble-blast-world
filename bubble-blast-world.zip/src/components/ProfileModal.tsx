/**
 * Bubble Blast World - Player Profile Modal
 */

import React, { useState } from 'react';
import { X, User, Edit2, Check, Award, Star, Coins } from 'lucide-react';
import { DEFAULT_AVATARS } from '../game/storage';
import { PlayerStats } from '../game/types';
import { sound } from '../game/sound';

interface ProfileModalProps {
  stats: PlayerStats;
  isOpen: boolean;
  onClose: () => void;
  onUpdateStats: (newStats: PlayerStats) => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  stats,
  isOpen,
  onClose,
  onUpdateStats,
}) => {
  const [isEditingName, setIsEditingName] = useState(false);
  const [usernameInput, setUsernameInput] = useState(stats.username);

  if (!isOpen) return null;

  const currentAvatar = DEFAULT_AVATARS.find((a) => a.id === stats.avatar) || DEFAULT_AVATARS[0];
  const totalStars = Object.values(stats.levelStars).reduce((acc, curr) => acc + curr, 0);

  const handleSaveName = () => {
    sound.click();
    const cleanName = usernameInput.trim() || 'Blaster Pilot';
    onUpdateStats({ ...stats, username: cleanName });
    setIsEditingName(false);
  };

  const handleSelectAvatar = (avatarId: string) => {
    sound.click();
    onUpdateStats({ ...stats, avatar: avatarId });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="relative w-full max-w-md max-h-[90vh] overflow-hidden rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-slate-950/90 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <User className="w-6 h-6 text-indigo-400" />
            <h2 className="text-xl font-bold text-white font-bubble">Player Profile</h2>
          </div>

          <button
            onClick={() => {
              sound.click();
              onClose();
            }}
            className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Avatar & Name Section */}
          <div className="flex flex-col items-center text-center p-4 bg-slate-950/60 rounded-2xl border border-slate-800">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-indigo-500 to-purple-500 p-0.5 mb-3 shadow-lg shadow-indigo-500/25">
              <div className="w-full h-full bg-slate-900 rounded-[14px] flex items-center justify-center text-4xl">
                {currentAvatar.icon}
              </div>
            </div>

            {/* Username */}
            {isEditingName ? (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  maxLength={18}
                  value={usernameInput}
                  onChange={(e) => setUsernameInput(e.target.value)}
                  className="bg-slate-800 border border-indigo-500 text-white text-sm font-bold px-3 py-1 rounded-xl text-center focus:outline-none"
                  autoFocus
                />
                <button
                  onClick={handleSaveName}
                  className="p-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl"
                >
                  <Check className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold text-white font-bubble">{stats.username}</span>
                <button
                  onClick={() => setIsEditingName(true)}
                  className="text-slate-400 hover:text-white transition-colors"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
              </div>
            )}
            <span className="text-xs text-indigo-400 font-semibold mt-0.5">{currentAvatar.name}</span>
          </div>

          {/* Select Avatar Grid */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Choose Avatar</span>
            <div className="grid grid-cols-6 gap-2">
              {DEFAULT_AVATARS.map((av) => (
                <button
                  key={av.id}
                  onClick={() => handleSelectAvatar(av.id)}
                  className={`p-2 rounded-xl text-2xl flex items-center justify-center transition-all ${
                    stats.avatar === av.id
                      ? 'bg-indigo-600 border-2 border-indigo-400 scale-105 shadow-md shadow-indigo-500/30'
                      : 'bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60'
                  }`}
                  title={av.name}
                >
                  {av.icon}
                </button>
              ))}
            </div>
          </div>

          {/* Detailed Stats */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Blaster Statistics</span>
            <div className="grid grid-cols-2 gap-2.5">
              <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/60">
                <div className="text-[11px] text-slate-400">Levels Cleared</div>
                <div className="text-base font-bold text-white font-mono">
                  {stats.unlockedLevel - 1} / 500
                </div>
              </div>

              <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/60">
                <div className="text-[11px] text-slate-400">Total Stars</div>
                <div className="text-base font-bold text-amber-400 font-mono flex items-center gap-1">
                  <Star className="w-4 h-4 fill-amber-400" />
                  <span>{totalStars}</span>
                </div>
              </div>

              <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/60">
                <div className="text-[11px] text-slate-400">Bubbles Popped</div>
                <div className="text-base font-bold text-sky-400 font-mono">
                  {stats.totalBubblesPopped.toLocaleString()}
                </div>
              </div>

              <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/60">
                <div className="text-[11px] text-slate-400">Gems Rescued</div>
                <div className="text-base font-bold text-purple-400 font-mono">
                  {stats.totalGemsRescued.toLocaleString()}
                </div>
              </div>

              <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/60">
                <div className="text-[11px] text-slate-400">Highest Combo</div>
                <div className="text-base font-bold text-orange-400 font-mono">
                  {stats.highestCombo}x
                </div>
              </div>

              <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/60">
                <div className="text-[11px] text-slate-400">Coins Balance</div>
                <div className="text-base font-bold text-amber-300 font-mono flex items-center gap-1">
                  <Coins className="w-4 h-4 text-amber-400" />
                  <span>{stats.coins.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
